/*
 * fdcan.c
 *
 *  Created on: Nov 18, 2022
 *      Author: abhishekk
 */
#include "main.h"

void CAN_initial_setup(void)
{
	set_receive_rules();
	if(HAL_FDCAN_ActivateNotification(&hfdcan1, FDCAN_IT_RX_FIFO0_NEW_MESSAGE|FDCAN_IT_TX_COMPLETE |FDCAN_IT_TX_FIFO_EMPTY, 0)!= HAL_OK)//
	{
		  Error_Handler();
	}
	HAL_FDCAN_Start(&hfdcan1);
	fdcan_data_sent = 1;
	fdcan_write_bytes(0x12345678,(uint8_t *)"\x01\x02\x03\x04\x05",5);
}

void set_receive_rules(void)
{
	FDCAN_FilterTypeDef sFilterConfig;

	//bms status filter
	sFilterConfig.FilterConfig 	= FDCAN_FILTER_TO_RXFIFO0;
	sFilterConfig.FilterID1 	= 0x0100E5F4;
	sFilterConfig.FilterID2 	= 0x1FFFFFFF;
	sFilterConfig.FilterIndex 	= 0x01;
	sFilterConfig.FilterType 	= FDCAN_FILTER_MASK;
	sFilterConfig.IdType 		= FDCAN_EXTENDED_ID;
	if(HAL_FDCAN_ConfigFilter(&hfdcan1, &sFilterConfig) != HAL_OK)
	{
		Error_Handler();
	}

	//bms profile filter
	sFilterConfig.FilterConfig 	= FDCAN_FILTER_TO_RXFIFO0;
	sFilterConfig.FilterID1 	= 0x0501E5F4;
	sFilterConfig.FilterID2 	= 0x1FFFFFFF;
	sFilterConfig.FilterIndex 	= 0x02;
	sFilterConfig.FilterType 	= FDCAN_FILTER_MASK;
	sFilterConfig.IdType 		= FDCAN_EXTENDED_ID;
	if(HAL_FDCAN_ConfigFilter(&hfdcan1, &sFilterConfig) != HAL_OK)
	{
		Error_Handler();
	}

	//extended id filter for PI loop configurations
	sFilterConfig.FilterConfig 	= FDCAN_FILTER_TO_RXFIFO0;
	sFilterConfig.FilterID1 	= 0x0902E5F4;
	sFilterConfig.FilterID2 	= 0x1FFFFFFF;
	sFilterConfig.FilterIndex 	= 0x03;
	sFilterConfig.FilterType 	= FDCAN_FILTER_MASK;
	sFilterConfig.IdType 		= FDCAN_EXTENDED_ID;
	if(HAL_FDCAN_ConfigFilter(&hfdcan1, &sFilterConfig) != HAL_OK)
	{
		Error_Handler();
	}

	//extended id filter for OVP and UVP configurations
	sFilterConfig.FilterConfig 	= FDCAN_FILTER_TO_RXFIFO0;
	sFilterConfig.FilterID1 	= 0x0D03E5F4;
	sFilterConfig.FilterID2 	= 0x1FFFFFFF;
	sFilterConfig.FilterIndex 	= 0x04;
	sFilterConfig.FilterType 	= FDCAN_FILTER_MASK;
	sFilterConfig.IdType 		= FDCAN_EXTENDED_ID;
	if(HAL_FDCAN_ConfigFilter(&hfdcan1, &sFilterConfig) != HAL_OK)
	{
		Error_Handler();
	}

}

void fdcan_write_bytes(unsigned int CAN_ID, uint8_t *dat, unsigned char DLC)
{
	FDCAN_TxHeaderTypeDef pTxHeader;
	//if((HAL_FDCAN_IsTxBufferMessagePending(&hfdcan1, 0x00)) == 0)
	if(fdcan_data_sent == 1)
	{
		fdcan_data_sent = 0;
		pTxHeader.DataLength = (uint32_t)((DLC<<16) & 0x000F0000U);
		pTxHeader.IdType = FDCAN_EXTENDED_ID;
		pTxHeader.Identifier = (uint32_t)(CAN_ID & 0x1FFFFFFF);
		pTxHeader.TxFrameType = FDCAN_DATA_FRAME;
		pTxHeader.BitRateSwitch = FDCAN_BRS_OFF;
		pTxHeader.FDFormat = FDCAN_CLASSIC_CAN;
		pTxHeader.MessageMarker = 0x00;
		pTxHeader.TxEventFifoControl = FDCAN_NO_TX_EVENTS;
		pTxHeader.ErrorStateIndicator = FDCAN_ESI_ACTIVE;
		if(HAL_FDCAN_AddMessageToTxFifoQ(&hfdcan1, &pTxHeader, dat) != HAL_OK)
		{
			Error_Handler();
		}
	}
//	while(HAL_FDCAN_IsTxBufferMessagePending(&hfdcan1, 0x00));
//	__asm("NOP");
}

void send_can_packets(void)
{
	switch(packet_state)
	{
		case 0: charger_info_update();
				break;
		case 1: charger_profile_update();
				break;
		case 2:	charger_fw_version_update();
				break;
		case 3:	config_update_feedback();
				break;
	}
	packet_state++;
	packet_state %= 4;

	//tx CAN message
	if((flags.bits.feedback_pi_loop != 0)||(packet_state != 0))//checking feedback_pi_loop flag
	{
		fdcan_write_bytes(can_tx_data.identifier.full_id, can_tx_data.data_byte, can_tx_data.DLC);
		if((flags.bits.feedback_pi_loop != 0) && (packet_state == 0))
		{
			flags.bits.feedback_pi_loop = 0;
		}
	}
}

//decode packet from BMS RXFIFO0
void process_fdcan_rx0(FDCAN_RxHeaderTypeDef *pRxHeader,uint8_t *dat)
{

	can_rx_data.DLC = pRxHeader->DataLength >> 16 & 0x0F;
	can_rx_data.identifier.full_id = pRxHeader->Identifier;
	memcpy(can_rx_data.data_byte,dat,8);
	if((can_rx_data.identifier.full_id == 0x0100E5F4)&&(can_rx_data.DLC == 8))
	{
		decode_bms_status(can_rx_data.data_byte);
		comm_fdcan_cnt 				= 0;
		faults.bits.can_com_fault 	= 0;
		flags.bits.can_receive 		|= 1;
	}
	if((can_rx_data.identifier.full_id == 0x0501E5F4)&&(can_rx_data.DLC == 8))
	{
		decode_bms_profile(can_rx_data.data_byte);
		comm_fdcan_cnt 				= 0;
		faults.bits.can_com_fault 	= 0;
		flags.bits.can_receive 		|= 2;
	}
	if((can_rx_data.identifier.full_id == 0x0902E5F4)&&(can_rx_data.DLC == 8))
	{
		decode_pi_loop(can_rx_data.data_byte);
		comm_fdcan_cnt 				= 0;
		faults.bits.can_com_fault 	= 0;
	}
	if((can_rx_data.identifier.full_id == 0x0D03E5F4)&&(can_rx_data.DLC == 8))
	{
		decode_ovp_uvp(can_rx_data.data_byte);
		comm_fdcan_cnt 				= 0;
		faults.bits.can_com_fault 	= 0;
	}
}


void decode_bms_profile(unsigned char *comm_array)
{
	static unsigned short temp_voltage = 0.0,temp_current = 0.0;
	can_rx_packet.bms_profile.max_current.bytes.MSB 		= *comm_array++;
	can_rx_packet.bms_profile.max_current.bytes.LSB 		= *comm_array++;
	can_rx_packet.bms_profile.max_voltage.bytes.MSB 		= *comm_array++;
	can_rx_packet.bms_profile.max_voltage.bytes.LSB 		= *comm_array++;
	can_rx_packet.bms_profile.cut_off_current.bytes.MSB 	= *comm_array++;
	can_rx_packet.bms_profile.cut_off_current.bytes.LSB 	= *comm_array++;
	can_rx_packet.bms_profile.pre_charge_current.bytes.MSB 	= *comm_array++;
	can_rx_packet.bms_profile.pre_charge_current.bytes.LSB 	= *comm_array;

	if(temp_current != can_rx_packet.bms_profile.max_current.word)
	{
		temp_current = can_rx_packet.bms_profile.max_current.word;
		REF_CURRENT = target_current = ((float)temp_current) / 1000;
	}
	if(temp_voltage != can_rx_packet.bms_profile.max_voltage.word)
	{
		temp_voltage = can_rx_packet.bms_profile.max_voltage.word;
		REF_VOLTAGE = target_voltage = ((float)temp_voltage) / 1000;
	}
}

void decode_bms_status(unsigned char *comm_array)
{
	can_rx_packet.bms_status.measured_current.bytes.MSB	= *comm_array++;
	can_rx_packet.bms_status.measured_current.bytes.LSB	= *comm_array++;
	can_rx_packet.bms_status.terminal_voltage.bytes.MSB	= *comm_array++;
	can_rx_packet.bms_status.terminal_voltage.bytes.LSB	= *comm_array++;
	comm_array++;
	comm_array++;
	can_rx_packet.bms_status.error_state				= *comm_array++;
	can_rx_packet.bms_status.temperature				= *comm_array;
	if(can_rx_packet.bms_status.error_state == 0)
	{
		charging_en = 1;
	}
	else
	{
		charging_en = 0;
	}
}

void decode_pi_loop(unsigned char *comm_array)
{
	_Words temp_data;
	temp_data.bytes.byte1	= *comm_array++;
	temp_data.bytes.byte0	= *comm_array++;
	Kp_V = ((float)(temp_data.dataword & 0xFFFF))/1000;
	temp_data.bytes.byte1	= *comm_array++;
	temp_data.bytes.byte0	= *comm_array++;
	Ki_V = ((float)(temp_data.dataword & 0xFFFF))/1000;
	temp_data.bytes.byte1	= *comm_array++;
	temp_data.bytes.byte0	= *comm_array++;
	Kp_C = ((float)(temp_data.dataword & 0xFFFF))/1000;
	temp_data.bytes.byte1	= *comm_array++;
	temp_data.bytes.byte0	= *comm_array++;
	Ki_C = ((float)(temp_data.dataword & 0xFFFF))/1000;
	flags.bits.feedback_pi_loop = 1;
}

void decode_ovp_uvp(unsigned char *comm_array)
{
	_Words temp_data;
	temp_data.bytes.byte1	= *comm_array++;
	temp_data.bytes.byte0	= *comm_array++;
	OVP_Level = ((float)(temp_data.dataword & 0xFFFF))/100;
	temp_data.bytes.byte1	= *comm_array++;
	temp_data.bytes.byte0	= *comm_array++;
	UVP_Level = ((float)(temp_data.dataword & 0xFFFF))/100;
}

void charger_info_update(void)
{
	can_tx_data.data_byte[0] 					= DEVICE_TYPE;
	can_tx_data.data_byte[1] 					= can_tx_packet.charger_info.ac_input;
	can_tx_data.data_byte[2] 					= can_tx_packet.charger_info.temperature;
	can_tx_data.data_byte[3] 					= can_tx_packet.charger_info.rms_voltage;
	can_tx_data.data_byte[4] 					= can_tx_packet.charger_info.status.byte;
	can_tx_data.data_byte[5] = can_tx_data.data_byte[6] = can_tx_data.data_byte[7] = 0x00;
	can_tx_data.identifier.full_id 				= 0;
	can_tx_data.identifier.bits.destination_add = 0xF4;
	can_tx_data.identifier.bits.source_add 		= 0xE5;
	can_tx_data.identifier.bits.message_id 		= 0x090;
	can_tx_data.identifier.bits.priority 		= 0;
	can_tx_data.DLC = 8;
}

void charger_profile_update(void)
{
	can_tx_data.data_byte[0] 					= can_tx_packet.charger_profile.out_current.bytes.MSB;
	can_tx_data.data_byte[1] 					= can_tx_packet.charger_profile.out_current.bytes.LSB;
	can_tx_data.data_byte[2] 					= can_tx_packet.charger_profile.out_voltage.bytes.MSB;
	can_tx_data.data_byte[3] 					= can_tx_packet.charger_profile.out_voltage.bytes.LSB;
	can_tx_data.data_byte[4] = can_tx_data.data_byte[5] = can_tx_data.data_byte[6] = can_tx_data.data_byte[7] = 0x00;
	can_tx_data.identifier.full_id 				= 0;
	can_tx_data.identifier.bits.destination_add = 0xF4;
	can_tx_data.identifier.bits.source_add 		= 0xE5;
	can_tx_data.identifier.bits.message_id 		= 0x091;
	can_tx_data.identifier.bits.priority 		= 1;
	can_tx_data.DLC = 8;
}

void charger_fw_version_update(void)
{
	memcpy(can_tx_data.data_byte,fw_array,8);
	can_tx_data.identifier.full_id 				= 0;
	can_tx_data.identifier.bits.destination_add = 0xF4;
	can_tx_data.identifier.bits.source_add 		= 0xE5;
	can_tx_data.identifier.bits.message_id 		= 0x092;
	can_tx_data.identifier.bits.priority 		= 2;
	can_tx_data.DLC = 8;
}

void encode_pi_loop(void)
{
	_Words temp_data;
	temp_data.dataword = (unsigned int)(Kp_V * 1000);
	can_tx_data.data_byte[0] = temp_data.bytes.byte1;
	can_tx_data.data_byte[1] = temp_data.bytes.byte0;
	temp_data.dataword = (unsigned int)(Ki_V * 1000);
	can_tx_data.data_byte[2] = temp_data.bytes.byte1;
	can_tx_data.data_byte[3] = temp_data.bytes.byte0;
	temp_data.dataword = (unsigned int)(Kp_C * 1000);
	can_tx_data.data_byte[4] = temp_data.bytes.byte1;
	can_tx_data.data_byte[5] = temp_data.bytes.byte0;
	temp_data.dataword = (unsigned int)(Ki_C * 1000);
	can_tx_data.data_byte[6] = temp_data.bytes.byte1;
	can_tx_data.data_byte[7] = temp_data.bytes.byte0;
}

void config_update_feedback(void)
{
	if(flags.bits.feedback_pi_loop == 1)
	{
		can_tx_data.identifier.full_id 				= 0;
		encode_pi_loop();
		can_tx_data.identifier.bits.message_id 	= 0x093;
		can_tx_data.identifier.bits.priority 	= 3;
		can_tx_data.identifier.bits.destination_add = 0xF4;
		can_tx_data.identifier.bits.source_add 		= 0xE5;
		can_tx_data.DLC = 8;
	}
}

void HAL_FDCAN_RxFifo0Callback(FDCAN_HandleTypeDef *hfdcan, uint32_t RxFifo0ITs)
{
	FDCAN_RxHeaderTypeDef pRxHeader;
	uint8_t pRxData[8]="";
	if(HAL_FDCAN_GetRxMessage(hfdcan, FDCAN_RX_FIFO0, &pRxHeader, pRxData) == HAL_OK)
	{
		process_fdcan_rx0(&pRxHeader,pRxData);
	}
}

void HAL_FDCAN_ErrorCallback(FDCAN_HandleTypeDef *hfdcan)
{
	if(hfdcan->ErrorCode != HAL_FDCAN_ERROR_NONE)
	{
		Error_Handler();
	}
}

void HAL_FDCAN_TxFifoEmptyCallback(FDCAN_HandleTypeDef *hfdcan)
{
  fdcan_data_sent = 1;
}

void fdcan_handler(void)
{
	uint32_t status = 0,en = 0;
	FDCAN_RxHeaderTypeDef pRxHeader;
	uint8_t pRxData[8]="";
	en 		= FDCAN1->IE;
	status 	= FDCAN1->IR;
	if((status & en) != 0)
	{
		if(status & 0x01)
		{
			if(HAL_FDCAN_GetRxMessage(&hfdcan1, FDCAN_RX_FIFO0, &pRxHeader, pRxData) == HAL_OK)
			{
				process_fdcan_rx0(&pRxHeader,pRxData);
			}
		}
		if(status & 0x200)
		{
			fdcan_data_sent = 1;
		}
		FDCAN1->IR = status;
	}
}

