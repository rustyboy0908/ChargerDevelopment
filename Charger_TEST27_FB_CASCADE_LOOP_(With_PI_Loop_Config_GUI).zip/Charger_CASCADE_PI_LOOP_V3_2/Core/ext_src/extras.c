/*
 * extras.c
 *
 *  Created on: 08-Apr-2023
 *      Author: Abhishek_R&D
 */
#include "main.h"

void update_target_voltage(float out_voltage)
{
	static float pre_out_voltage = 0.0;
	if(pre_out_voltage != out_voltage)
	{
		pre_out_voltage = out_voltage;
		//voltage divider 10k:300k and diode voltage drop of 0.5V
		target_voltage_count = (out_voltage - diode_drop) * voltage_constant;
	}
}

void update_target_current(float out_current)
{
	static float pre_out_current = 0.0;
	if(pre_out_current != out_current)
	{
		pre_out_current = out_current;
		//in mV // 100mV * 10 = 1000mA
		target_current_count = out_current * current_constant;
	}
}

void pi_loop_new3(void)
{
    static short mode_change = 0;
    int high_limit=0,low_limit=0;
    float negative = target_current_count*(-1.0);

    ERR_VOLTAGE_COUNT = (target_voltage_count - (float)llc_v_sense_avg);

	integral_V  += (Ki_V * ERR_VOLTAGE_COUNT);

    if(integral_V > target_current_count)//4095)
    {
    	integral_V = target_current_count;//4095;
    }
    else if(integral_V < negative)//-4095)
    {
    	integral_V = negative;//-4095;
    }
    pi_sum_V = ((Kp_V * ERR_VOLTAGE_COUNT) + integral_V);

    if(pi_sum_V >= target_current_count)
    {
    	mode_change++;
    	if(mode_change >= 70)
    	{
    		mode_change = 70;
    		if(target_current != REF_CURRENT)
    		{
				target_current = REF_CURRENT;
				update_target_current(REF_CURRENT);		//CC current set
    		}
			pi_sum_V = pi_sum_V1 = target_current_count;
			CC_CV_Check = 	CV_MODE;
    	}
    }
    else
    {
    	if(mode_change > 0)
    	{
    		mode_change--;
    	}
    	else
    	{
			if(pi_sum_V <= 0)
			{
				pi_sum_V1 =	pi_sum_V = 0;
			}
			else
			{
				pi_sum_V1 =	pi_sum_V;
			}
			CC_CV_Check = 	CC_MODE;
			if(target_current != (REF_CURRENT))// + 1.0
			{
				target_current = REF_CURRENT;// + 1.0
				update_target_current(REF_CURRENT);//+1.0		//CC current set + 1.0 for hysteresis
			}
		}
    }

	ERR_CURRENT_COUNT = pi_sum_V1 - (float)i_sense_avg;
	integral_C  += (Ki_C * ERR_CURRENT_COUNT);

    if(integral_C > target_current_count)//4095)
    {
    	integral_C = target_current_count;//4095;
    }
    else if(integral_C < negative)//-4095)
    {
    	integral_C = negative;//-4095;
    }
    if(CC_CV_Check != SOFT_MODE)
    {
    	pi_sum_C = ((Kp_C * ERR_CURRENT_COUNT) + integral_C);
    }
    else
    {
    	pi_sum_C = pi_sum_V;
    }

	if(pi_sum_C < 0.0)
	{
		temp_dac_out += 1;
	}
	else if(pi_sum_C > 0)
	{
		temp_dac_out -= 1;
	}

	//temp_dac_out = (unsigned int)pi_sum_C;

	//For FB Pin DAC control un-comment two lines below
	high_limit = 2800 * MUL_FACTOR;  //2800 for 1.9 Gain
	low_limit  = 2606 * MUL_FACTOR;  //2606 for 1.9 Gain

	if(temp_dac_out < low_limit)
	{
		temp_dac_out = low_limit;
	}
	else if(temp_dac_out > high_limit)
	{
		temp_dac_out = high_limit;
	}
	dac_out_count = temp_dac_out / MUL_FACTOR;//temp_in;//
	if(pre_value_dac != dac_out_count)
	{
		pre_value_dac = dac_out_count;
		DAC1->DHR12R1 = pre_value_dac;
	}
}

