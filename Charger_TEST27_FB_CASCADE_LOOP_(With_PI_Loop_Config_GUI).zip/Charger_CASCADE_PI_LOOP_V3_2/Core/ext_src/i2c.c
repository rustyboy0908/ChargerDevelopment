/*
 * i2c.c
 *
 *  Created on: 06-Feb-2023
 *      Author: abhishekk
 */

#include "main.h"

void i2c_delay(unsigned int delay_temp1)
{
	while(delay_temp1--)
	{
		__asm("NOP");
	}
}

void i2c_init(void)
{
	I2C_SCL_DIR(1);
	I2C_SDA_DIR(1);
	I2C_SCL(1);
	I2C_SDA(1);
}

void i2c_start(void)
{
	I2C_SDA(1);
	i2c_delay(scl_clock*2);
	I2C_SCL(1);
	i2c_delay(scl_clock);
	I2C_SDA(0);
	i2c_delay(scl_clock);
	I2C_SCL(0);
}

void i2c_stop(unsigned short value)
{
	I2C_SDA(0);
	i2c_delay(scl_clock);
	I2C_SCL(1);
	i2c_delay(scl_clock);
	I2C_SDA(1);
	i2c_delay(value);
}

HAL_StatusTypeDef i2c_send(unsigned char dat,unsigned int timeout)
{
	unsigned char i = 0;
	for(i=0;i<8;i++)
	{
		if((dat<<i) & 0x80)
		{
			I2C_SDA(1);
		}
		else
		{
			I2C_SDA(0);
		}
		I2C_SCL(1);
		i2c_delay(scl_clock);
		I2C_SCL(0);
		i2c_delay(scl_clock);
	}
	I2C_SDA_DIR(0);
	I2C_SCL(1);
	i2c_delay(scl_clock);
	while(I2C_SDA_IN);
//	do{
//		timeout--;
//	}while(I2C_SDA_IN && timeout);
	I2C_SCL(0);
	i2c_delay(scl_clock);

	I2C_SDA_DIR(1);
	if(timeout == 0) return HAL_ERROR;
	else return HAL_OK;
}


void i2c_read(unsigned char *dat,unsigned char ack)
{
	unsigned char i = 0,data_1=0;
	I2C_SDA_DIR(0);
	for(i=0;i<8;i++)
	{
		data_1 *= 2;
		I2C_SCL(1);
		i2c_delay(scl_clock);
		if(I2C_SDA_IN)
		{
			data_1 |= 0x01;
		}
		I2C_SCL(0);
		i2c_delay(scl_clock);
	}
	I2C_SDA_DIR(1);
	if(ack == 0)
	{
		I2C_SDA(0);
	}
	else
	{
		I2C_SDA(1);
	}
	I2C_SCL(1);
	i2c_delay(scl_clock);
	I2C_SCL(0);
	i2c_delay(scl_clock);
	*dat = data_1;
}

/**
  * @brief  Writes one byte of data into an eeprom address location using I2C
  * @param  "add" field of 16 bits address.
  * @param	"dat" one byte of which needs to be write by user
  * @retval HAL status
  */
HAL_StatusTypeDef write_byte_eeprom(unsigned short add, unsigned char dat)
{
	HAL_StatusTypeDef ret = HAL_OK;
	unsigned char device_add = 0xA0 | (((unsigned char)(add>>7)) & 0x06);
	i2c_start();

	if(i2c_send(device_add,10000) != HAL_OK){
		ret = HAL_ERROR;
		goto end;
	}
	if(i2c_send((unsigned char)add,10000) != HAL_OK){
		ret = HAL_ERROR;
		goto end;
	}
	if(i2c_send(dat,10000) != HAL_OK){
		ret = HAL_ERROR;
		goto end;
	}
	end:
	i2c_stop(i2c_clock_stop);
	return ret;
}

/**
  * @brief  reads one byte of data into an eeprom address location using I2C
  * @param  "add" field of 16 bits address.
  * @param	"dat" one byte of data which will update after reading address from eeprom
  * 		as pointer
  * @retval HAL status
  */
HAL_StatusTypeDef read_byte_eeprom(unsigned short add, unsigned char *dat)
{
	HAL_StatusTypeDef ret = HAL_OK;
	unsigned char value = 0;
	unsigned char device_add = 0xA0 | (((unsigned char)(add>>7)) & 0x06);
	i2c_start();
	if(i2c_send(device_add,10000) != HAL_OK){
		ret = HAL_ERROR;
		goto end;
	}
	if(i2c_send((unsigned char)add,10000) != HAL_OK){
		ret = HAL_ERROR;
		goto end;
	}
	//i2c_stop(i2c_clock_stop);
	i2c_start();
	if(i2c_send(device_add+1,10000) != HAL_OK){
		ret = HAL_ERROR;
		goto end;
	}
	i2c_read(&value,1);
	*dat = value;
	end:
	i2c_stop(i2c_clock_stop);
	return ret;
}

void eeprom_1kbytes_test(void)
{
	unsigned char tx_aray[11]="Abhishek\r\n",rx_aray[11];
	i2c_init();
	for(int i=0;i<10;i++)
	{
		if(write_byte_eeprom(i,tx_aray[i]) != HAL_OK)
		{
			Error_Handler();
		}
	}
	for(int j=0;j<10;j++)
	{
		if(read_byte_eeprom(j,&rx_aray[j]) != HAL_OK)
		{
			Error_Handler();
		}
	}
}
