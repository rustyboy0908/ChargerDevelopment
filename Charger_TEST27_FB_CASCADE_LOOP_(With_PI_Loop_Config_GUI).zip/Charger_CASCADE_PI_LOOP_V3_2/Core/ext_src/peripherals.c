/*
 * peripherals.c
 *
 *  Created on: Nov 4, 2022
 *      Author: abhishekk
 */


/* Includes ------------------------------------------------------------------*/
#include "main.h"


/* This function activate Timers, PWm, Capturing,
 * ADC, DAC modules
 * Arguments: Null
 * Return 	: Null
 * */
void user_setup(void)
{
    //Default value 0V DAC1 and DAC
	DAC1->DHR12R1 = 4095;
	DAC1->DHR12R2 = 0;
	//calibrate ADC channels for first time
	HAL_ADCEx_Calibration_Start(&hadc1);
	//Start DAC channels
	HAL_DAC_Start(&hdac1, DAC_CHANNEL_1);
	HAL_DAC_Start(&hdac1, DAC_CHANNEL_2);

	TIM2->CCR1 = CP_DUTY;
	HAL_TIM_PWM_Start(&htim2, TIM_CHANNEL_1);
	//FD CAN Startup
	CAN_initial_setup();
	//start capturing earth frequency
	HAL_TIM_IC_Start_IT(&htim16,TIM_CHANNEL_1);
	// Start The timer
	HAL_TIM_Base_Start_IT(&htim6); 	// 1 msec
	HAL_TIM_Base_Start_IT(&htim1); 	// 100 usec
//	restart_system();
	HAL_GPIO_WritePin(LED1D_GPIO_Port, LED1D_Pin|LED2D_Pin, 0);
	HAL_ADC_Start_DMA(&hadc1, (uint32_t*)adc_results, adc_array_len);

	CC_CV_Check 	= CC_MODE;
	charge_complete	= NOT_DONE;
	state_charging 	= CONSTANT_CURRENT;
	target_current 	= REF_CURRENT;			//CC current set
	target_voltage 	= REF_VOLTAGE;			//Boundary voltage for CC
	can_rx_packet.bms_profile.max_current.word = (unsigned short)(target_current * 1000);
	can_rx_packet.bms_profile.max_voltage.word = (unsigned short)(target_voltage * 1000);
	 /************** Updating the Voltage & Current************/
	update_target_voltage(REF_VOLTAGE);		//Boundary voltage for CV
	update_target_current(REF_CURRENT);		//CC current set

	//HAL_Delay(1000);
	IN_RLY_ON;//Enable Input Relay
	HAL_Delay(1000);
	PFC_CTRL_ENABLE;//Enable PFC

//	charging_en = 0;
//	charging_mode = 0xFF;

//	stop_charging();
//	flags.bits.global_error = 1;

	charging_en = 1;
	charging_mode = 0x0;
}

/* This function read all ADC channels using DMA
 * updates global ADC variables
 * Arguments: Null
 * Return 	: Null
 * */
void ADC_Read(void)
{
	if(conversion_complt)
	{
		conversion_complt = 0;
		i_sense_result 		= adc_results[0];//i_sense_result
		v_sense_result 		= adc_results[1];//v_sense_result
		ext_ntc_result 		= adc_results[2];//ext_ntc_result
		cp_neg_result 		= adc_results[3];//cp_neg_result
		cp_pos_result 		= adc_results[4];//cp_pos_result
		llc_v_sns_result	= adc_results[5];//llc_v_sns_result
		ntc1_result 		= adc_results[6];//ntc1_result
		ac_sense_result 	= adc_results[7];//ntc1_result
		HAL_ADC_Start_DMA(&hadc1, (uint32_t*)adc_results, adc_array_len);
	}
}

volatile unsigned short volt_arr[17],curr_arr[17],sample_complete = 0;
unsigned long volt_avg = 0,curr_avg = 0,llc_v_avg = 0;
volatile int ad_i = 0;

void ADC_Sample(void)
{
	volt_avg += v_sense_result;
	curr_avg += i_sense_result;
	llc_v_avg += llc_v_sns_result;
	ad_i++;
	if(ad_i >= 16)
	{
		v_sense_avg 	= volt_avg >> 4;
		i_sense_avg 	= curr_avg >> 4;
		llc_v_sense_avg = llc_v_avg >> 4;
		volt_avg = curr_avg = llc_v_avg = ad_i = 0;
	}
}

void ADC_calc(void)
{
	read_battery();
	read_llc_voltage();
    read_batt_current();
    read_inst_battery();
    read_inst_batt_current();
}


/**
  * @brief  PWM out at TIM14 and channel 1
  * @param  "period" field which is responsible for time period (0 to 65535)
  * @param	"duty" is PWM duty cycle (ON time percentage)  (0 to 100)
  * @retval Null
  */
void cp_pwm_out(unsigned int period,unsigned char duty)
{
	TIM14->ARR = period-1;
	/* Set the Capture Compare Register value */
	TIM14->CCR1 = ((period * duty)/100);
	/* Set the Preload enable bit for channel2 */
	TIM14->CCMR1 |= TIM_CCMR1_OC1PE;
}
void average_data(void)
{
	static unsigned short index_a = 0;
	static unsigned int v_sense_temp = 0,i_sense_temp = 0;
	v_sense_temp += v_sense_result;
	i_sense_temp += i_sense_result;
	index_a++;
	if(index_a >= 70)
	{
		v_sense_avg = v_sense_temp / 70;
		i_sense_avg = i_sense_temp / 70;
		v_sense_temp = 0;
		i_sense_temp = 0;
		index_a = 0;
	}
}

//Charger Algo Start

void ADC_aveg_Val(void)
{
	static unsigned char avg_index = 0;
	static unsigned int v_sum = 0, i_sum = 0;
	unsigned char i = 0;
	v_arr[avg_index] = v_sense_avg;//v_sense_result;
	i_arr[avg_index] = i_sense_avg;//i_sense_result;
	avg_index++;
	if(avg_index >= 10)
	{
		flags.bits.avg_complt = 1;
		avg_index = 1;
	}

	if(flags.bits.avg_complt == 1)
	{
		for(i=0;i<10;i++)
		{
			v_sum += v_arr[i];
			i_sum += i_arr[i];
		}
		B_Sense		=	v_sum / 10;
		I_sense		=	i_sum / 10;
		v_sum = 0;
		i_sum = 0;
		v_arr[0] = B_Sense;
		i_arr[0] = I_sense;

//		B_Sense_Cal	= 	(mx_voltage/HIGH_LIMIT_VAL);
//		B_Sense_Cal	= 	B_Sense_Cal*B_Sense;
		B_Sense_Cal	= 	(mx_voltage*B_Sense);
		B_Sense_Cal	= 	B_Sense_Cal/HIGH_LIMIT_VAL;

//		I_Sense_Cal	= 	(mx_current/HIGH_LIMIT_VAL);
//		I_Sense_Cal	= 	I_Sense_Cal*I_sense;
		I_Sense_Cal	= 	(mx_current*I_sense);
		I_Sense_Cal	= 	I_Sense_Cal/HIGH_LIMIT_VAL;

		can_tx_packet.charger_profile.out_current.word = I_Sense_Cal*MX_RESOLUTION15;
		can_tx_packet.charger_profile.out_voltage.word = B_Sense_Cal*MX_RESOLUTION15;
	}


}
//Charger Algo End
