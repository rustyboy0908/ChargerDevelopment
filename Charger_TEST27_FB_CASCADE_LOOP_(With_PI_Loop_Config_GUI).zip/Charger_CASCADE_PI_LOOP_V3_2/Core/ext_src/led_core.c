/*
 * led_core.c
 *
 *  Created on: Nov 15, 2022
 *      Author: abhishekk
 */

#include "main.h"

void leds_run(void)
{
	run_red_led();
	run_yellow_led();
	run_mains_led();
}

void run_red_led(void)
{
	if(red_led.cnt < red_led.mode)
	{
		RED_H;
	}
	else
	{
		RED_L;
	}
	red_led.cnt++;
	red_led.cnt %= red_led.total;
}

void run_yellow_led(void)
{
	if(yellow_led.cnt < yellow_led.mode)
	{
		YELLOW_H;
	}
	else
	{
		YELLOW_L;
	}
	yellow_led.cnt++;
	yellow_led.cnt %= yellow_led.total;
}

void run_mains_led(void)
{
	if(mains_led.cnt < mains_led.mode)
	{
		MAINS_H;
	}
	else
	{
		MAINS_L;
	}
	mains_led.cnt++;
	mains_led.cnt %= mains_led.total;
}

void set_leds(LEDs *ledx, unsigned char mode)
{
	switch((int)mode)
	{
		case OFF:	ledx->cnt 	= 0;
					ledx->mode 	= 0;
					ledx->total = 1;
					break;

		case ON:	ledx->cnt 	= 0;
					ledx->mode 	= 1;
					ledx->total = 1;
					break;

		case BLINK:	ledx->cnt 	= 0;
					ledx->mode 	= 50;
					ledx->total = 100;
					break;

		case BLINK25:
					ledx->cnt 	= 0;
					ledx->mode 	= 25;
					ledx->total = 50;
					break;
	}
}

void charging_ind(void)
{
	set_leds(&red_led,BLINK);
	set_leds(&yellow_led,BLINK);
	set_leds(&mains_led,BLINK);
}

void cut_off_ind(void)
{
	set_leds(&red_led,OFF);
	set_leds(&yellow_led,OFF);
	set_leds(&mains_led,OFF);
}

void charged_ind(void)
{
	set_leds(&red_led,ON);
	set_leds(&yellow_led,ON);
	set_leds(&mains_led,ON);
}

void short_circuit_ind(void)
{
	set_leds(&mains_led,ON);
	set_leds(&red_led,BLINK25);
	set_leds(&yellow_led,BLINK25);
}

void battery_reverse_ind(void)
{
	set_leds(&mains_led,ON);
	set_leds(&red_led,BLINK25);
	set_leds(&yellow_led,BLINK);
}

void voltage_not_in_range_ind(void)
{
	set_leds(&mains_led,ON);
	set_leds(&red_led,BLINK25);
	set_leds(&yellow_led,ON);
}

void battery_not_connect_ind(void)
{
	set_leds(&mains_led,ON);
	set_leds(&red_led,BLINK25);
	set_leds(&yellow_led,OFF);
}

void comm_flt_ind(void)
{
	set_leds(&red_led,ON);
	set_leds(&yellow_led,BLINK);
	set_leds(&mains_led,BLINK25);
}

void mosfet_over_temp(void)
{
	set_leds(&mains_led,ON);
	set_leds(&red_led,BLINK);
	set_leds(&yellow_led,BLINK);
}

void transformer_over_temp(void)
{
	set_leds(&mains_led,ON);
	set_leds(&red_led,BLINK);
	set_leds(&yellow_led,BLINK);
}

void diode_over_temp(void)
{
	set_leds(&mains_led,ON);
	set_leds(&red_led,BLINK);
	set_leds(&yellow_led,BLINK);
}

void bms_over_temp(void)
{
	set_leds(&mains_led,ON);
	set_leds(&red_led,BLINK);
	set_leds(&yellow_led,ON);
}

void charger_over_voltage_ind(void)
{
	set_leds(&mains_led,ON);
	set_leds(&red_led,BLINK);
	set_leds(&yellow_led,OFF);
}

void charger_over_current_ind(void)
{
	set_leds(&mains_led,ON);
	set_leds(&red_led,ON);
	set_leds(&yellow_led,BLINK25);
}

void over_voltage_ind(void)
{
	set_leds(&red_led,BLINK25);
	set_leds(&yellow_led,ON);
	set_leds(&mains_led,BLINK);
}

void under_voltage_ind(void)
{
	set_leds(&red_led,BLINK);
	set_leds(&yellow_led,ON);
	set_leds(&mains_led,ON);
}

void abnormal_earth_ind(void)
{
	set_leds(&mains_led,ON);
	set_leds(&red_led,ON);
	set_leds(&yellow_led,OFF);
}

void pfc_failure_ind(void)
{
	set_leds(&mains_led,ON);
	set_leds(&red_led,OFF);
	set_leds(&yellow_led,BLINK25);
}

void stage_HMI(unsigned char value)
{
	if(disp_state != value)
	{
		disp_state = value;
		switch((int)disp_state)
		{
			case CHARGING:		charging_ind();
								break;

			case CUT_OFF:		cut_off_ind();
								break;

			case CHARGED:		charged_ind();
								break;

			case CHARGE_SC:		short_circuit_ind();
								break;

			case BATT_REV:		battery_reverse_ind();
								break;

			case BATT_NO_RANGE:	voltage_not_in_range_ind();
								break;

			case BATT_NOT_CN:	battery_not_connect_ind();
								break;

			case COM_FLT:		comm_flt_ind();
								break;

			case MOS_OT:		mosfet_over_temp();
								break;

			case TRFMR_OT:		transformer_over_temp();
								break;

			case DIODE_OT:		diode_over_temp();
								break;

			case BMS_OT:		bms_over_temp();
								break;

			case CHARGE_OV:		charger_over_voltage_ind();
								break;

			case CHARGE_OC:		charger_over_current_ind();
								break;

			case OVR_VOLT:		over_voltage_ind();
								break;

			case UND_VOLT:		under_voltage_ind();
								break;

			case AB_EARTH:		abnormal_earth_ind();
								break;

			case PFC_FAIL:		pfc_failure_ind();
								break;

			default:			break;
		}
	}
}
