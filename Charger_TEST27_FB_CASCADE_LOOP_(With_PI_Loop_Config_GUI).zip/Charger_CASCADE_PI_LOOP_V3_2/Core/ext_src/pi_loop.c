/*
 * pi_loop.c
 *
 *  Created on: 13-Mar-2023
 *      Author: Abhishek_R&D
 */

#include "main.h"

void delay_us(unsigned int val)
{
	while(val--)
	{
		__asm("NOP");
	}
}

void read_battery(void)
{
    mV_value =((float) v_sense_avg);
    //voltage divider 10k:300k and diode voltage drop of 0.5V
    battery_voltage	= (float)((mV_value / voltage_constant) + diode_drop + voltage_calibrate);
}

void read_llc_voltage(void)
{
    mV_value =(float) llc_v_sense_avg;
    //voltage divider 10k:300k and diode voltage drop of 0.5V
    llc_voltage 	= (float)((mV_value / voltage_constant) + diode_drop);
}

void read_batt_current(void)
{
	mV_value =(float) i_sense_avg;
	//in mV // 100mV * 10 = 1000mA
	battery_curr 	= (float) (mV_value / current_constant);
}

void read_inst_battery(void)
{
    mV_value =(float) v_sense_result;
    //voltage divider 10k:300k and diode voltage drop of 0.5V
    battery_inst_voltage =(float)((mV_value / voltage_constant) + diode_drop);
}

void read_inst_batt_current(void)
{
	mV_value =(float) i_sense_result;
	//in mV // 100mV * 10 = 1000mA
	battery_inst_curr 	=(float) (mV_value / current_constant);
}

void change_to_standby(void)
{
	CC_CV_Check 	= CC_MODE;
	charge_complete	= DONE;
	state_charging 	= STANDBY;
	target_current 	= TC_CURRENT;			//Trickle charge current

	//need to check
	target_voltage 	= (REF_VOLTAGE - 12);	//Boundary voltage for trickle
}

void change_to_trickle(void)
{
	CC_CV_Check 	= CC_MODE;
	charge_complete	= NOT_DONE;
	state_charging 	= TRICKLE_CHARGE;
	target_current 	= TC_CURRENT;			//Trickle charge current

	//need to check
	target_voltage 	= (REF_VOLTAGE - 20);	//Boundary voltage for trickle
}

void change_to_cc(void)
{
	CC_CV_Check 	= CC_MODE;
	charge_complete	= NOT_DONE;
	state_charging 	= CONSTANT_CURRENT;
	target_current 	= CC_CURRENT_LEVEL;		//CC current set

	//need to check
	target_voltage 	= REF_VOLTAGE;			//Boundary voltage for CC
}

void change_to_cv(void)
{
	CC_CV_Check 	= CV_MODE;
	charge_complete	= NOT_DONE;
	state_charging 	= CONSTANT_VOLTAGE;
	target_voltage 	= REF_VOLTAGE;			//Boundary voltage for CC

	//need to check
	target_current 	= CC_CURRENT_LEVEL;		//CC current set
}

void change_to_charged(void)
{
	CC_CV_Check 	= CV_MODE;
	charge_complete	= NOT_DONE;
	state_charging 	= CHARGE_COMPLETE;
	target_voltage 	= REF_VOLTAGE;			//Boundary voltage for CC

	//need to check
	target_current 	= CC_CURRENT_LEVEL;		//CC current set
}

//void stop_charging(void)
//{
//	flags.bits.cc_dac_check =0;
//	flags.bits.cv_dac_check =0;
//	//I_Out = CHAR_CURR_0_0 ;
//	// Disable Charging Enable bit.
//	//charging_en = 0;
//	I_DUMMY= CHAR_CURR_0_0;
//	I_Out= (I_DUMMY/4095)*mx_current;
//	DAC1->DHR12R1 = 4095;//I_DUMMY;
//	//GPIOB->ODR &= ~(1 << 11);	//disable Input Relay
//	OUT_RLY_L;
//	LLC_CTRL_DISABLE;	//llc ctrl disable
//	PFC_CTRL_DISABLE;	//Disable PFC
//}

void stop_charging(void)
{
    if (charging_mode != 0xFF)
    {
    	OUT_RLY_OFF;			//OUT Relay Off
        LLC_CTRL_DISABLE;		//LLC Control Disable
        PFC_CTRL_DISABLE;		//PFC Control Disable
        charging_en 	= 0;	// Disable Charging Enable bit.
        charging_mode 			= 0xFF;
        flags.bits.pi_loop_en 	= 0;
        DAC1->DHR12R1 			= 4095;	//Maximum FB voltage to minimize O/P voltage
        HAL_Delay(3000);
    }
}

void charging_control(void)
{
	if(charging_en == 0)
	{
		if(charging_mode != 0)
		{
			charging_mode = 0;
			stop_charging();
		}
	}
	else
	{
		if(charging_mode != 0xFF)
		{
			HAL_Delay(100);
			PFC_CTRL_ENABLE;//Enable PFC
			HAL_Delay(2000);
			LLC_CTRL_ENABLE;	//llc ctrl enable
			short i = 4095;
			for(i=4095;i > 2624;i--)
			{
				DAC1->DHR12R1 = i;
				HAL_Delay(3);
			}
			pre_value_dac = i;
			OUT_RLY_ON;
			restart_system();
			charging_en = 1;
			charging_mode = 0xFF;
		}
	}
}
