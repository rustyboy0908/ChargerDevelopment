/*
 * abnormal.c
 *
 *  Created on: 22-Nov-2022
 *      Author: abhishekk
 */

#include "main.h"

//this function repeat @ every 250ms
void earth_detection(void)
{
   freq_array[earth_index] = frequency;
   earth_index++;
   if((earth_index >= 40)|| (flags.bits.f_array_complt==1))
   {
	   if((earth_index >= 40)|| (flags.bits.f_array_complt==0))
		   earth_index = 0;
	   flags.bits.f_array_complt = 1;
       temp_frequency = 0;
       for(int loop=0;loop<40;loop++)
       {
           temp_frequency += freq_array[loop];
       }
       earth_frequency = temp_frequency / 40;
   }
   else
   {
       if(flags.bits.f_array_complt == 0)
       {
           earth_frequency = frequency;
       }
   }
   if((earth_frequency < 30)||(earth_frequency > 70) || (flags.bits.earth_check==0))
   {
	   if(flags.bits.global_error != 1)
	   {
		   faults.bits.earth_detect = 1;
		   flags.bits.global_error = 1;
		   flags.bits.f_array_complt = 0;
		   earth_frequency=frequency=0;
		   //stop_charging();
	   }
   }
   else if((earth_frequency > 35)&&(earth_frequency < 65))
   {
	   faults.bits.earth_detect = 0;
   }
   flags.bits.earth_check=0;
}

//this function repeat @ every 250ms
void ac_sensing(void)
{
	duty_array[ac_index] = duty_width;
	ac_index++;
	if((ac_index >= 40)||(flags.bits.d_array_complt == 1))
	{
		if((ac_index >= 40)||(flags.bits.d_array_complt == 0))
			ac_index = 0;
		flags.bits.d_array_complt = 1;
		temp_duty = 0;
		for(int loop=0;loop<40;loop++)
		{
			temp_duty += duty_array[loop];
		}
		ac_duty = temp_duty / 40;
	}
	else
	{
		if(flags.bits.d_array_complt == 0)
		{
			ac_duty = duty_width;
		}
	}


	if((ac_duty < UNDER_VOLTAGE_LIMIT)||(ac_duty > OVER_VOLTAGE_LIMIT) ||(flags.bits.ac_check==0))
	{
		if(ac_duty < UNDER_VOLTAGE_LIMIT)
		{
			faults.bits.ac_under_volt = 1;
			faults.bits.ac_over_volt = 0;
		}
		else
		{
			faults.bits.ac_under_volt = 0;
			faults.bits.ac_over_volt = 1;
		}

		if(flags.bits.global_error != 1)
		{
			flags.bits.global_error = 1;
			flags.bits.d_array_complt = 0;
			ac_index = 0;
			ac_duty=duty_width=width=0;
			//stop_charging();
		}
	}
	else if((ac_duty > U_REC_VOLTAGE_LIMIT)&&(ac_duty < O_REC_VOLTAGE_LIMIT))
	{
		faults.bits.ac_under_volt = 0;
		faults.bits.ac_over_volt = 0;
	}
	flags.bits.ac_check = 0;
	can_tx_packet.charger_info.rms_voltage = can_tx_packet.charger_info.ac_input = (unsigned char)((((ac_duty/10.75)+0.08)*(VOLTAGE_RATIO/1.414)) - 50.0);//conversion from duty to ac input
}

void check_output_current(void)
{
	if(battery_inst_curr > SC_CURRENT_VAL)
	{
		i_sc_count++;
		if(i_sc_count > 3)
		{
			i_sc_count = 3;
		}
	}
	else if(battery_inst_curr > ABNORMAL_CURRENT_VAL)	//if(i_sense_result > ABNORMAL_CURRENT_VAL)
	{
		i_ab_count++;
		if(i_ab_count > 1000)
		{
			i_ab_count = 1000;
		}
	}
	else
	{
		if(i_ab_count > 0)
		{
			i_ab_count--;
		}
	}


	if((i_ab_count == 1000)||(i_sc_count == 3))
	{
		if(i_ab_count == 1000)
			faults.bits.over_current = 1;
		else
			faults.bits.sc_current = 1;

		if(flags.bits.global_error != 1)
		{
			flags.bits.global_error = 1;
			stop_charging();
		}
	}
}

void check_pfc(void)
{
	if(PFC_OK_LV_IN != 0) //  if PFC is high means PFC feedback failure
	{
		pfc_count++;
		if(pfc_count > 3)
		{
			pfc_count = 3;
		}
	}
	else
	{
		if(pfc_count > 0)
		{
			pfc_count--;
		}
	}
	if(pfc_count == 3)
	{
		if(flags.bits.global_error != 1)
		{
			flags.bits.global_error = 1;
			faults.bits.pfc_not_ok 	= 1;
			flags.bits.pre_pfc_not_ok = 1;
			stop_charging();
			LLC_CTRL_DISABLE;//LLC disable
			PFC_CTRL_DISABLE;//PFC disable
		}
	}
	if(pfc_count==0)
	{
		faults.bits.pfc_not_ok 	= 0;
	}
}

void check_for_battery(void)
{
	if(flags.bits.charging == 1)
	{
		if(battery_voltage < BATT_NOT_CONN_VAL)
		{
			batt_index++;
			if(batt_index > 10)
			{
				batt_index = 10;
			}
		}
		else
		{
			if(batt_index > 0)
			{
				batt_index--;
			}
		}
		if(batt_index == 10)
		{
			if(flags.bits.global_error != 1)
			{
				flags.bits.global_error = 1;
				faults.bits.batt_not_connect = 1;
				stop_charging();

			}
		}
		else if(batt_index==0)
		{
			faults.bits.batt_not_connect = 0;
		}
	}
}

void check_for_battery_voltage(void)
{
	if(flags.bits.charging == 1)
	{
		if(battery_inst_voltage > OVP_Level)// ABNORMAL_VOLTAGE_VAL)
		{
			batt_count++;
			if(batt_count > 10)
			{
				batt_count = 10;
			}
		}
		else
		{
			if(batt_count > 0)
			{
				batt_count--;
			}
		}
		if(batt_count == 10)
		{
			if(flags.bits.global_error != 1)
			{
				flags.bits.global_error = 1;
				faults.bits.output_over_voltage = 1;
				stop_charging();

			}
		}
	}
}

void check_for_battery_config(void)
{
	if((can_rx_packet.bms_profile.max_voltage.word / MX_RESOLUTION01) > CHARGER_MAX_VOLTAGE)
	{
		if(flags.bits.global_error != 1)
		{
			flags.bits.global_error = 1;
			faults.bits.batt_volt_not_in_range = 1;
			stop_charging();

		}
	}
	else
	{
		faults.bits.batt_volt_not_in_range = 0;
	}
}

void check_for_communication(void)
{
	if(faults.bits.can_com_fault == 1)
	{
		if(flags.bits.global_error != 1)
		{
			flags.bits.global_error 							= 1;
			//reset received CAN data and flags
			flags.bits.can_receive								= 0;
			can_rx_packet.bms_profile.cut_off_current.word 		= 0;
			can_rx_packet.bms_profile.max_current.word 			= 0;
			can_rx_packet.bms_profile.max_voltage.word 			= 0;
			can_rx_packet.bms_profile.pre_charge_current.word 	= 0;
			can_rx_packet.bms_status.error_state 				= 0;
			can_rx_packet.bms_status.measured_current.word 		= 0;
			can_rx_packet.bms_status.temperature 				= 0;
			can_rx_packet.bms_status.terminal_voltage.word		= 0;
			can_rx_data.DLC 									= 0;
			can_rx_data.identifier.full_id 						= 0;
			memcpy(can_rx_data.data_byte,"\x00\x00\x00\x00\x00\x00\x00\x00",8);
			stop_charging();
		}
	}
}

void check_for_hard_fault(void)
{
	static unsigned char hf_state = 0;
	switch((int)hf_state)
	{
		case 0:		//output short circuit or over-current sensing
					//check_output_current();
					break;

		case 1:		//pfc fault sensing
					//check_pfc();
					break;

		case 2:		//battery connection sensing
					check_for_battery();
					break;

		case 3:		//battery voltage sensing
					//check_for_battery_voltage();
					break;

		case 4:		//battery voltage and current validation
					//check_for_battery_config();
					break;

		case 5:		//can bus checking
					//check_for_communication();
					break;

		default:	hf_state = 5;
					break;
	}
	hf_state++;
	hf_state %= 6;
}

void error_handler(void)
{
    static int err_state = 0;
    if(flags.bits.global_error == 0)
    {
    	check_for_hard_fault();
    }
    else
    {
		switch(err_state)
		{
			case 0: //Battery Short circuit fault
					if(faults.bits.sc_current == 1)
					{
						can_tx_packet.charger_info.status.byte = 0x01;
						stage_HMI(CHARGE_SC);
					}
					else
					{
						err_state = 1;
					}
					break;

			case 1: //Battery Reverse connected
					if(faults.bits.batt_reverse == 1)
					{
						can_tx_packet.charger_info.status.byte = 0x02;
						stage_HMI(BATT_REV);
					}
					else
					{
						err_state = 2;
					}
					break;
			case 2://Battery Voltage is out of range
					if(faults.bits.batt_volt_not_in_range == 1)
					{
						can_tx_packet.charger_info.status.byte = 0x03;
						stage_HMI(BATT_NO_RANGE);
					}
					else
					{
						err_state = 3;
					}
					break;
			case 3: //Battery is disconnected
					if(faults.bits.batt_not_connect == 1)
					{
						can_tx_packet.charger_info.status.byte = 0x04;
						stage_HMI(BATT_NOT_CN);
					}
					else
					{
						err_state = 4;
					}
					break;

			case 4: //Lost CAN Bus
					if(faults.bits.can_com_fault == 1)
					{
						can_tx_packet.charger_info.status.byte = 0x05;
						stage_HMI(COM_FLT);
					}
					else
					{
						err_state = 5;
					}

			case 5: //Charger Over MOSFET Temperature
					if(charger.ntc.bits.pri_mosfet == HIGH)
					{
						can_tx_packet.charger_info.status.byte = 0x06;
						stage_HMI(MOS_OT);
					}
					else
					{
						err_state = 6;
					}
					break;

			case 6: //Charger Over DIODE Temperature
					if(charger.ntc.bits.sec_diode == HIGH)
					{
						can_tx_packet.charger_info.status.byte = 0x06;
						stage_HMI(DIODE_OT);
					}
					else
					{
						err_state = 7;
					}
					break;

			case 7: //Charger Over Transformer Temperature
					if(charger.ntc.bits.transformer == HIGH)
					{
						can_tx_packet.charger_info.status.byte = 0x06;
						stage_HMI(TRFMR_OT);
					}
					else
					{
						err_state = 8;
					}
					break;

			case 8: //Battery Over Temperature
					if(charger.ntc.bits.bms == HIGH)
					{
						can_tx_packet.charger_info.status.byte = 0x06;
						stage_HMI(BMS_OT);
					}
					else
					{
						err_state = 9;
					}
					break;

			case 9: //Charger Over Voltage
					if(faults.bits.output_over_voltage == 1)
					{
						can_tx_packet.charger_info.status.byte = 0x07;
						stage_HMI(CHARGE_OV);
					}
					else
					{
						err_state = 10;
					}
					break;

			case 10://Charger Over Current
					if(faults.bits.over_current == 1)
					{
						can_tx_packet.charger_info.status.byte = 0x08;
						stage_HMI(CHARGE_OC);
					}
					else
					{
						err_state = 11;
					}
					break;

			case 11://AC input out of range
					if(faults.bits.ac_under_volt == 1)
					{
						can_tx_packet.charger_info.status.byte = 0x09;
						stage_HMI(UND_VOLT);
					}
					else if(faults.bits.ac_over_volt == 1)
					{
						can_tx_packet.charger_info.status.byte = 0x09;
						stage_HMI(OVR_VOLT);
					}
					else
					{
						err_state = 12;
					}
					break;

			case 12://Internal Error as Earth fail
					if(faults.bits.earth_detect == 1)
					{
						can_tx_packet.charger_info.status.byte = 0x0A;
						stage_HMI(AB_EARTH);
					}
					else
					{
						err_state = 13;
					}
					break;

			case 13://Internal Error as PFC or LLC fail
					if(faults.bits.pfc_not_ok == 1)
					{
						can_tx_packet.charger_info.status.byte = 0x0A;
						stage_HMI(PFC_FAIL);
					}
					else
					{
						err_state = 0;
					}
					break;
		}
		if(flags.bits.request_reset == 1)
		{
			start_LLC();
		}
    }
}

void start_LLC(void)
{
	static unsigned int llc_state = 0;
		static short dac_i = 4095;
		switch(llc_state)
		{
			case 0:	if((faults.bits.ac_under_volt == 0)&&(faults.bits.ac_over_volt == 0))
					{
						PFC_CTRL_ENABLE;//Enable PFC
						ms_cnt = 100;	//timer state halt for 100ms
						llc_state = 1;
					}
					else
					{
						flags.bits.request_reset = 0;
						error_cnt = 0;
					}
					break;

			case 1:	if(ms_cnt == 0)
					{
						if(PFC_OK_LV_IN == 0)
						{
							LLC_CTRL_ENABLE;			//llc ctrl enable
							llc_state = 2;
						}
						else
						{
							PFC_CTRL_DISABLE;			//Disable PFC
							flags.bits.request_reset = 0;
							error_cnt = 0;
						}
					}
					break;

			case 2:	if(PFC_OK_LV_IN == 0)
					{
						if((dac_i > 2624)&&(ms_cnt == 0))
						{
							DAC1->DHR12R1 = dac_i--;
							ms_cnt = 3;				//timer state halt for 3ms
						}
						if(dac_i == 2624)
						{
							pre_value_dac 	= dac_i;
							dac_i 			= 4095;
							llc_state 		= 3;
							ms_cnt 			= 100;	//timer state halt for 100ms
						}
					}
					else
					{
						LLC_CTRL_DISABLE;			//llc ctrl disable
						PFC_CTRL_DISABLE;			//Disable PFC
						error_cnt = 0;
						flags.bits.request_reset = 0;
					}
					break;
			case 3:	if(ms_cnt == 0)
					{
						if((llc_voltage >= 58.0)&&(llc_voltage <= 62.0))
						{
							target_voltage 			= battery_voltage - 1;
							flags.bits.pi_loop_en 	= 1;
							CC_CV_Check				= SOFT_MODE;
							ms_cnt 					= 500;	//timer state halt for 100ms
							llc_state 				= 4;
						}
						else
						{
							LLC_CTRL_DISABLE;		//llc ctrl disable
							PFC_CTRL_DISABLE;		//Disable PFC
							error_cnt = 0;
							flags.bits.request_reset = 0;
						}
					}
					break;
			case 4:	if(ms_cnt == 0)
					{
						if((ERR_VOLTAGE_COUNT < 2.0)&&(ERR_VOLTAGE_COUNT > -2.0))
						{
							restart_system();
							OUT_RLY_ON;
							flags.bits.pi_loop_en 		= 1;
							llc_state 					= 0;
						}
						else
						{
							LLC_CTRL_DISABLE;		//llc ctrl disable
							PFC_CTRL_DISABLE;		//Disable PFC
							error_cnt = 0;
							flags.bits.request_reset = 0;
						}
					}
					break;
		}
}

void restart_system(void)
{
	//Re-initialize variables
	ac_index 			= 0;
	i_ab_count 			= 0;
	i_sc_count 			= 0;
	pfc_count 			= 0;
	batt_index 			= 0;
	batt_count 			= 0;
	earth_index 		= 0;
	faults.data 		= 0;
	flags.data_info 	= 0;
	flags.bits.charging = 1;
	can_tx_packet.charger_info.status.byte = 0x30;

	//For restarting charging sequence
	CC_CV_Check 	= CC_MODE;
	charge_complete	= NOT_DONE;
	state_charging 	= CONSTANT_CURRENT;
	target_current 	= REF_CURRENT;			//CC current set
	target_voltage 	= REF_VOLTAGE;			//Boundary voltage for CV
	update_target_voltage(REF_VOLTAGE);		//Boundary voltage for CV
	update_target_current(REF_CURRENT);		//CC current set
}
