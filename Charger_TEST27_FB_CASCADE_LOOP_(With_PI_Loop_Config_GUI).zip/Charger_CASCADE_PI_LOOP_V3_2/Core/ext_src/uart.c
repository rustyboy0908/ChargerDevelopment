/*
 * uart.c
 *
 *  Created on: Nov 7, 2022
 *      Author: rishabhs
 */

#include "main.h"

void process_uart(unsigned char data)
{
	//HAL_UART_Receive_IT(&hlpuart2, RX_data, 16);

}

//for transmission use HAL_UART_Transmit_IT(&hlpuart2, TX_data, 16);
