/*
 * process.c
 *
 *  Created on: Nov 4, 2022
 *      Author: abhishekk
 */
#include "main.h"

/**
  * @brief  This function call in infinite while loop as system state machine
  * @param  Null
  * @retval Null
  */
void user_loop(void)
{
	switch((int)sys_state)
	{
		case 1:		update_target_voltage(target_voltage);
					update_target_current(target_current);
					ADC_calc();
					sys_state = 2;
					break;

		case 2:		//This function will call at every 10 millisecond
					update_in_10ms();
					sys_state = 3;
					break;

		case 3:		//This function will call at every 25 millisecond
					update_in_25ms();
					sys_state = 4;
					break;

		case 4:		//This function will call at every 250 millisecond
					update_in_250ms();
					sys_state = 5;
					break;

		case 5:		//error detection section
					//error_handler();
					sys_state = 1;
					break;

		default: 	sys_state = 1;
					break;
	}
}


/**
  * @brief  This function will repeat at every 10ms which handles
  * CAN timeout, ADC reading operations and LED indications
  * @param  Null
  * @retval Null
  */
void update_in_10ms(void)
{
	static unsigned char temp_cnt10 = 0;
	if(flags.bits.msec_10)
	{
		flags.bits.msec_10 = 0;
		comm_fdcan_cnt++;
		if(comm_fdcan_cnt >= 500)
		{
			comm_fdcan_cnt 				= 500;
			faults.bits.can_com_fault	= 1;
		}
		adc_reading_states();
		leds_run();
		temp_cnt10++;
		if(temp_cnt10 >= 10)
		{
			temp_cnt10 					= 0;
			flags.bits.charging_algo 	= 1;	//set at every 100ms
		}
	}
}
/**
  * @brief  This function will repeat at every 250ms which handles
  * state machine, all NTC temperature control, AC sensing and earth sensing
  * @param  Null
  * @retval Null
  */
void update_in_250ms(void)
{
	if(flags.bits.msec_250)
	{
		flags.bits.msec_250 = 0;
		//state_machine();
		//temperature_control();
		//ac_sensing();
		//earth_detection();
		if(flags.bits.global_error == 1)
		{
			error_cnt++;
			if(error_cnt >= 32)
			{
				error_cnt = 0;
				flags.bits.request_reset = 1;
			}
		}
	}
}

/**
  * @brief  This function will repeat at every 25ms which handles
  * can packets transmission each packet will send @100ms
  * @param  Null
  * @retval Null
  */
void update_in_25ms(void)
{
	if((flags.bits.msec_25))//&&(charging_en))
	{
		flags.bits.msec_25 = 0;
		send_can_packets();
	}
}

/**
  * @brief  This is an ADC state machine
  * @param  Null
  * @retval Null
  */
void adc_reading_states(void)
{
	static int chl = 4;
	switch(chl)
	{
		case 4:		//chl = func_ntc1();
					chl = 5;
					break;

		case 5:		//chl = func_ntc2();
					chl = 6;
					break;

		case 6:		chl = func_ntc3();
					break;

		default:	chl = 4;
	}
}

/**
  * @brief  This function averages NTC1 ADC value and take decision respectively
  * @param  Null
  * @retval adc state machine number
  */
int func_ntc1(void)
{
	static unsigned char index = 0;
	unsigned char loop = 0;
	int ret = 4;
	adc_ntc.adc_arr[index] = ntc1_result;
	index++;
	if(index >= 10)
	{
		index = 0;
		adc_ntc.sum = 0;
		for(loop = 0; loop < 10; loop++)
		{
			adc_ntc.sum += adc_ntc.adc_arr[loop];
		}
		adc_ntc.value1 = (unsigned short)(adc_ntc.sum / 10);
		ntc1_temp_C = adc_to_temp(adc_ntc.value1);
		can_tx_packet.charger_info.temperature = ntc1_temp_C;
		ntc1_decision();
		ret = 5;
	}
	return ret;
}

/**
  * @brief  This function averages NTC2 ADC value and take decision respectively
  * @param  Null
  * @retval adc state machine number
  */
int func_ntc2(void)
{
	static unsigned char index = 0;
	unsigned char loop = 0;
	int ret = 5;
	adc_ntc.adc_arr[index] = llc_v_sns_result;
	index++;
	if(index >= 10)
	{
		index = 0;
		adc_ntc.sum = 0;
		for(loop = 0; loop < 10; loop++)
		{
			adc_ntc.sum += adc_ntc.adc_arr[loop];
		}
		adc_ntc.value2 = (unsigned short)(adc_ntc.sum / 10);
		ntc2_temp_C = adc_to_temp(adc_ntc.value2);
		//ntc2_decision();
		llc_v_decision();
		ret = 6;
	}
	return ret;
}

/**
  * @brief  This function averages NTC3 ADC value and take decision respectively
  * @param  Null
  * @retval adc state machine number
  */
int func_ntc3(void)
{
	static unsigned char index = 0;
	unsigned char loop = 0;
	int ret = 6;
	adc_ntc.adc_arr[index] = ext_ntc_result;
	index++;
	if(index >= 10)
	{
		index = 0;
		adc_ntc.sum = 0;
		for(loop = 0; loop < 10; loop++)
		{
			adc_ntc.sum += adc_ntc.adc_arr[loop];
		}
		adc_ntc.value3 = (unsigned short)(adc_ntc.sum / 10);
		ntc3_temp_C = adc_to_temp(adc_ntc.value3);
		ntc3_decision();
		ret = 4;
	}
	return ret;
}
/**
  * @brief  This function will monitors temperature of Primary
  * MOSFET and updates current state of temperature range, if temperature is higher than
  * HIGH temperature threshold then global error is generated and charger stops.
  * @param  Null
  * @retval Null
  */
void ntc1_decision(void)
{
	if(ntc1_temp_C > PRI_MOS_TEMP_HIGH)
	{
		if(charger.ntc.bits.pri_mosfet != HIGH)
		{
			charger.ntc.bits.pri_mosfet = HIGH;
			if(flags.bits.global_error != 1)
			{
				flags.bits.global_error = 1;
				stop_charging();
			}
		}
	}
	else if((ntc1_temp_C < (PRI_MOS_TEMP_HIGH-2))&&(ntc1_temp_C > PRI_MOS_TEMP_MID))
	{
		charger.ntc.bits.pri_mosfet = LVL2;
	}
	else if((ntc1_temp_C < (PRI_MOS_TEMP_MID-2))&&(ntc1_temp_C > PRI_MOS_TEMP_NORM))
	{
		charger.ntc.bits.pri_mosfet = LVL1;
	}
	else if(ntc1_temp_C < (PRI_MOS_TEMP_NORM-2))
	{
		charger.ntc.bits.pri_mosfet = NORM;
	}
}

/**
  * @brief  This function will monitors temperature of Transformer
  * and updates current state of temperature range, if temperature is higher than
  * HIGH temperature threshold then global error is generated and charger stops.
  * @param  Null
  * @retval Null
  */
void llc_v_decision(void)
{

}

//void ntc2_decision(void)
//{
//	if(ntc2_temp_C > TRNSFMR_TEMP_HIGH)
//	{
//		if(charger.ntc.bits.transformer != HIGH)
//		{
//			if(charger.ntc.bits.transformer != HIGH)
//			{
//				charger.ntc.bits.transformer = HIGH;
//				if(global_error != 1)
//				{
//					global_error = 1;
//					stop_charging();
//				}
//			}
//		}
//	}
//	else if((ntc2_temp_C < (TRNSFMR_TEMP_HIGH-2))&&(ntc2_temp_C > TRNSFMR_TEMP_MID))
//	{
//		charger.ntc.bits.transformer = LVL2;
//	}
//	else if((ntc2_temp_C < (TRNSFMR_TEMP_MID-2))&&(ntc2_temp_C > TRNSFMR_TEMP_NORM))
//	{
//		charger.ntc.bits.transformer = LVL1;
//	}
//	else if(ntc2_temp_C < (TRNSFMR_TEMP_NORM-2))
//	{
//		charger.ntc.bits.transformer = NORM;
//	}
//}

/**
  * @brief  This function will monitors temperature of Secondary
  * Diode and updates current state of temperature range, if temperature is higher than
  * HIGH temperature threshold then global error is generated and charger stops.
  * @param  Null
  * @retval Null
  */
void ntc3_decision(void)
{
	if(ntc3_temp_C > S_DIODE_TEMP_HIGH)
	{
		if(charger.ntc.bits.sec_diode != HIGH)
		{
			charger.ntc.bits.sec_diode = HIGH;
			if(flags.bits.global_error != 1)
			{
				flags.bits.global_error = 1;
				stop_charging();
			}
		}
	}
	else if((ntc3_temp_C < (S_DIODE_TEMP_HIGH-2))&&(ntc3_temp_C > S_DIODE_TEMP_MID))
	{
		charger.ntc.bits.sec_diode = LVL2;
	}
	else if((ntc3_temp_C < (S_DIODE_TEMP_MID-2))&&(ntc3_temp_C > S_DIODE_TEMP_NORM))
	{
		charger.ntc.bits.sec_diode = LVL1;
	}
	else if(ntc3_temp_C < (S_DIODE_TEMP_NORM-2))
	{
		charger.ntc.bits.sec_diode = NORM;
	}
}

/**
  * @brief  This function call in infinite while loop as system state machine
  * @param  "period" field which is responsible for time period (0 to 65535)
  * @param	"duty" is PWM duty cycle (ON time percentage)  (0 to 100)
  * @retval Null
  */
void temperature_control(void)
{
	unsigned char temp_val = 0;
	if((bypass_temp_check == 0)&&(flags.bits.global_error == 0))
	{
		if(temp_val < charger.ntc.bits.pri_mosfet)
		{
			temp_val = charger.ntc.bits.pri_mosfet;
		}
		if(temp_val < charger.ntc.bits.transformer)
		{
			temp_val = charger.ntc.bits.transformer;
		}
		if(temp_val < charger.ntc.bits.sec_diode)
		{
			temp_val = charger.ntc.bits.sec_diode;
		}
		if(temp_val < charger.ntc.bits.bms)
		{
			temp_val = charger.ntc.bits.bms;
		}

		if(temp_val == HIGH)
		{
			//cut off charging
			if(hw_state.bits.batt_cut_off != 1)
			{
				hw_state.bits.batt_cut_off 	= 1;	//cut-off the charger
				charger.current_level 		= 0;	//zero current
				stop_charging();
			}
		}
		else if(temp_val == LVL2)
		{
			//current set to 78% of rated current
			charger.current_level	= (NOMINAL_CURRENT * 78)/100;	//indicating nominal current
		}
		else if(temp_val == LVL1)
		{
			//current set to 33% of rated current
			charger.current_level 	= (NOMINAL_CURRENT * 33)/100;	//indicating nominal current
		}
		else
		{
			//if temperature is normal then current tend to rated current
			charger.current_level 	= NOMINAL_CURRENT;	//indicating nominal current
		}

		if(charger.current_level != 0)//if temperature has recovered
		{
			if(hw_state.bits.batt_cut_off != 0)
			{
				//restart charging sequence
				hw_state.bits.batt_cut_off = 0;	//no cut-off
				restart_system();
			}
		}
	}
}

/**
  * @brief  This function call in infinite while loop as system state machine
  * @param  "period" field which is responsible for time period (0 to 65535)
  * @param	"duty" is PWM duty cycle (ON time percentage)  (0 to 100)
  * @retval Null
  */
void state_machine(void)
{
	if(charger.batt_status == STATE_NOT_CHARGING)
	{
		stage_HMI(CHARGED);
	}
	else if(charger.batt_status == STATE_CHARGING)
	{
		stage_HMI(CHARGING);
	}
	else if(charger.batt_status == STATE_BROWN)
	{
		stage_HMI(CUT_OFF);
	}
}

/**
  * @brief  This function call in infinite while loop as system state machine
  * @param  "period" field which is responsible for time period (0 to 65535)
  * @param	"duty" is PWM duty cycle (ON time percentage)  (0 to 100)
  * @retval Null
  */
signed short adc_to_temp(unsigned short adc_val)
{
	/*NTC Resistance = ((3.3V - NTC_Voltage)/NTC_Voltage)*Reference Resistance
	 * adc_val 				= NTC_Voltage
	 * 3.3V 				= 4095
	 * Reference Resistance = 10000 Ohm*/
	average = (float)adc_val;
	//__asm("NOP");
	// Calculate NTC resistance
	average = ((4095-average) / average);
	//__asm("NOP");
	average = Rref * average;										//NTC Resistance
	//__asm("NOP");

	temperature = average / nominal_resistance;     				// (R/Ro)
	//__asm("NOP");
	temperature = (log10(temperature)/0.4343);                  	// ln(R/Ro) => log10(R/Ro)/log10(e)
	//__asm("NOP");
	temperature /= beta;                   							// 1/B * ln(R/Ro)
	//__asm("NOP");
	temperature += 1.0 / (nominal_temeprature + 273.15); 			// + (1/To)
	//__asm("NOP");
	temperature = 1.0 / temperature;                 				// Invert (result is in kelvin)
	//__asm("NOP");
	temperature -= 273.15;                         					// convert absolute temp to C
	//__asm("NOP");

	return ((signed short)temperature);
}


