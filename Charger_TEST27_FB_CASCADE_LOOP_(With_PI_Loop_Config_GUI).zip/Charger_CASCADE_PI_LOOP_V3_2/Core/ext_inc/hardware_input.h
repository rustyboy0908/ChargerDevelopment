/*
 * hardware_input.h
 *
 *  Created on: 13-Dec-2022
 *      Author: abhishekk
 */

#ifndef INC_HARDWARE_INPUT_H_
#define INC_HARDWARE_INPUT_H_

#define REFER_VOLT		100	//48V
#define REFER_CURR		200	//5Amp


#define V_REF			250000//(((((REFER_VOLT * 100) - 500) / 31) * 4095) / 33)//250000//
#define I_REF			250000((REFER_CURR * 4095) / 33) //250000
#define Kp				10
#define Ki				0.1
#define Kp_I			10
#define Ki_I			0.1
#define C_Resolution 	256

#endif /* INC_HARDWARE_INPUT_H_ */
