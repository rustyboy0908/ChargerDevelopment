/*
 * i2c.h
 *
 *  Created on: 06-Feb-2023
 *      Author: abhishekk
 */

#ifndef INC_I2C_H_
#define INC_I2C_H_

#define scl_clock		25		//~10us
#define i2c_clock_stop	25000	//3.6ms
//PB3 SCL
#define I2C_SCL_DIR(v)		do{										\
								GPIOB->MODER &= ~(3<<6);			\
								if(v == 1) GPIOB->MODER |= (1<<6);	\
							}while(0U);

#define I2C_SCL(v)			do{										\
								if(v == 0) GPIOB->ODR &= ~(1<<3);	\
								else GPIOB->ODR |= (1<<3);			\
								__ASM("NOP");						\
							}while(0U);

//PB4 SDA
#define I2C_SDA_DIR(v)		do{										\
								GPIOB->MODER &= ~(3<<8);__ASM("NOP");			\
								if(v == 1) {GPIOB->MODER |= (1<<8);	}\
								__ASM("NOP");						\
							}while(0U);

#define I2C_SDA(v)			do{										\
								if(v == 0) GPIOB->ODR &= ~(1<<4);	\
								else GPIOB->ODR |= (1<<4);			\
								__ASM("NOP");						\
							}while(0U);

#define I2C_SDA_IN			(GPIOB->IDR & (1<<4))

void i2c_delay(unsigned int delay_temp1);
void i2c_init(void);
void i2c_start(void);
void i2c_stop(unsigned short value);
HAL_StatusTypeDef i2c_send(unsigned char dat,unsigned int timeout);
void i2c_read(unsigned char *dat,unsigned char ack);
HAL_StatusTypeDef write_byte_eeprom(unsigned short add, unsigned char dat);
HAL_StatusTypeDef read_byte_eeprom(unsigned short add, unsigned char *dat);
void eeprom_1kbytes_test(void);

#endif /* INC_I2C_H_ */
