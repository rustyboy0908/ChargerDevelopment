/*
 * variables.h
 *
 *  Created on: 20-Mar-2023
 *      Author: abhishekk
 */

#ifndef INC_VARIABLES_H_
#define INC_VARIABLES_H_

//user global variables
#ifdef _MAIN_DEF
volatile unsigned char pfc_ok_signal = 0,error_cnt,us_100 = 0,charging_en = 1;
unsigned int pre_value_dac=0,curr_value_dac=0,ms_cnt = 0;
float ERR_VOLTAGE = 0.0, ERR_CURRENT = 0.0, test_error=0.0, integral = 0.0, integral_C = 0.0,integral_V = 0.0;
float Kp_C = 1/*60.0*/, Ki_C = 1/*0.001*/, Kp_V = 1, Ki_V = 30;
float pi_sum = 0.0,pi_sum_C = 0.0, pi_sum_V = 0.0,pi_sum_V1 = 0.0;
float OVP_Level = ABNORMAL_VOLTAGE_VAL, UVP_Level = 35.0;
unsigned int dac_out_count = 1400,temp_dac_out = 4095,MUL_FACTOR = 100,temp_in=2771;//1983;
float ret_value=0;
float current_constant = 124.1, voltage_constant = 40.03, diode_drop = 0.1;
unsigned char state_charging = STANDBY;
unsigned char charge_complete = NOT_DONE;
cv_cc_type CC_CV_Check = CC_MODE;
float mV_value=0.0,battery_voltage=0.0,battery_curr=0.0,llc_voltage = 0.0,battery_inst_voltage = 0.0,battery_inst_curr = 0.0;
uint32_t voltage_out = 0;float REF_VOLTAGE = 54.1,REF_CURRENT = 12.0, TC_CURRENT = 1.5, target_voltage = 0.0, target_current = 0.0, tvo_count = 0, tcu_count = 0; // in volts
signed int ev = 0, prev_error = 0, Vkp = 0, Vinteg = 0, Vloopout =0;
uint32_t current_out = 0;
signed int ei = 0, prev_error_I = 0, Ikp = 0, Iinteg = 0, Iloopout =0;
unsigned int v_sense_avg = 0,i_sense_avg = 0,llc_v_sense_avg = 0;
LEDs red_led, yellow_led, mains_led;
ADC_NTC adc_ntc;
CHARGER charger;
HW_STATE hw_state;
FAULTS faults;
CAN_FORMAT can_tx_data,can_rx_data;
CAN_TX_PACKET can_tx_packet;
CAN_RX_PACKET can_rx_packet;
FLAGS flags;
volatile unsigned char conversion_complt = 0,send_packet = 0,fdcan_data_sent = 0;
volatile unsigned short adc_results[8];
const int adc_array_len = sizeof(adc_results) / sizeof(adc_results[0]);
unsigned short ntc1_result = 0,llc_v_sns_result=0,ext_ntc_result=0,v_sense_result=0,i_sense_result=0,cp_neg_result=0,cp_pos_result=0,ac_sense_result=0;

unsigned char receive_packet =0;
unsigned char TX_data[4]=""; 		// Tx storage Data
unsigned char RX_data[4]="";		 // RX storage data
unsigned char count =0;
UARTstatusDef UART_Status ;
unsigned char sys_state=0,packet_state = 0;
int32_t timer_DC=0;
volatile uint16_t EARTH_IC_VAL1 = 0, EARTH_IC_VAL2 = 0, AC_IC_VAL1 = 0, AC_IC_VAL2 = 0;
volatile uint16_t earth_diff = 0, ac_diff = 0;
volatile uint8_t is_first_captured1 = 0, is_first_captured2 = 0,duty_width = 0;
float frequency,width;
unsigned short comm_fdcan_cnt = 0;
unsigned char disp_state = 0;
signed short ntc1_temp_C = 0, ntc2_temp_C = 0, ntc3_temp_C = 0;
float temperature=0.0,average=0.0;
unsigned short freq_array[40];
unsigned long temp_frequency=0;
unsigned int earth_frequency=0;

unsigned short duty_array[40];
unsigned long temp_duty=0;
unsigned int ac_duty=0;
unsigned char bypass_temp_check = 0;
unsigned char earth_index = 0;
unsigned char ac_index = 0;
unsigned short i_ab_count = 0,i_sc_count = 0;
unsigned char pfc_count = 0;
unsigned char batt_index = 0;
unsigned char batt_count = 0;
unsigned char ds103_receive = 0;

//Charger Algo variables start

/* CHARGER VARIABLE DECLARATION*/

unsigned short I_sense = 0, B_Sense = 0;
unsigned short T_sense =0;
double I_Out = 0, Y_Out = 0;
unsigned char charging_mode = 0xFF;
double error_current, error_voltage;
unsigned short v_i_Loop=0;

/* Variables for dummy Code*/
float I_DUMMY=0;
float B_DUMMY=0;
unsigned short VOLT_ARR[100]={};
unsigned short I_ARR[100]={};
unsigned short VOLT_SUM=0;
unsigned short CURRENT_SUM=0;
double B_Sense_Cal=0;
double I_Sense_Cal=0;
double delta_Curr =0;
charStatus state_check = 0xFF;
unsigned char delta=0xFF;
unsigned int loop = 0;
long loop2=0;
uint32_t startTime =0;
uint32_t currentTime=0;
uint32_t mode_sTime=0; // Mode Start Tick Count.
uint32_t mode_eTime=0; // Mode End Tick Count.
uint32_t value_avg=0;
uint32_t deltaTickle =0;
uint32_t deltaSoftStart=0;
uint32_t deltaCC=0;
uint32_t deltaCV=0;
uint32_t deltaTOTALTIME=0;
uint32_t chargerTime=0;
uint32_t chargerEndTime=0;
uint16_t mx_current=0;
uint16_t mx_voltage=0;
uint16_t trickle_charge=0;
uint16_t cuttoff_voltage=0;
uint16_t min_current=0;
unsigned short v_arr[10],i_arr[10];
//Charger Algo variables end

unsigned char rec1 = 0,rec2 = 0;
float target_voltage_count = 0.0, target_current_count = 0.0;
float ERR_VOLTAGE_COUNT=0.0,ERR_CURRENT_COUNT=0.0;
float voltage_calibrate = 0.0,current_calibrate = 0.0;
#else
extern volatile unsigned char pfc_ok_signal,error_cnt,us_100,charging_en;
extern unsigned int pre_value_dac, curr_value_dac,ms_cnt;
extern float ERR_VOLTAGE, ERR_CURRENT, test_error, integral,integral_C,integral_V;
extern float Kp_C, Ki_C,Kp_V,Ki_V;
extern float pi_sum,pi_sum_C,pi_sum_V,pi_sum_V1;
extern float OVP_Level,UVP_Level;
extern unsigned int dac_out_count, temp_dac_out, MUL_FACTOR, temp_in;
extern float ret_value;
extern float current_constant, voltage_constant, diode_drop;
extern unsigned char state_charging;
extern unsigned char charge_complete;
extern cv_cc_type CC_CV_Check;
extern float mV_value,battery_voltage,battery_curr,llc_voltage,battery_inst_voltage,battery_inst_curr;
extern uint32_t voltage_out;
extern float REF_VOLTAGE,REF_CURRENT, TC_CURRENT, target_voltage, tvo_count, tcu_count, target_current; // in volts
extern signed int ev, prev_error, Vkp, Vinteg, Vloopout;
extern uint32_t current_out;
extern signed int ei, prev_error_I, Ikp, Iinteg, Iloopout;
extern unsigned int v_sense_avg,i_sense_avg,llc_v_sense_avg;
extern unsigned char rec1,rec2;
extern LEDs red_led, yellow_led, mains_led;
extern ADC_NTC adc_ntc;
extern CHARGER charger;
extern HW_STATE hw_state;
extern FAULTS faults;
extern FLAGS flags;
extern CAN_FORMAT can_tx_data,can_rx_data;
extern CAN_TX_PACKET can_tx_packet;
extern CAN_RX_PACKET can_rx_packet;
extern ADC_HandleTypeDef hadc1;
extern DMA_HandleTypeDef hdma_adc1;

extern DAC_HandleTypeDef hdac1;

extern FDCAN_HandleTypeDef hfdcan1;

//extern I2C_HandleTypeDef hi2c2;

extern UART_HandleTypeDef hlpuart2;
//extern IWDG_HandleTypeDef hiwdg;
extern TIM_HandleTypeDef htim1;
extern TIM_HandleTypeDef htim2;
extern TIM_HandleTypeDef htim3;
extern TIM_HandleTypeDef htim6;
extern TIM_HandleTypeDef htim16;

extern volatile unsigned char conversion_complt,send_packet,fdcan_data_sent;
extern volatile unsigned short adc_results[8];
extern const int adc_array_len;
extern unsigned short ntc1_result,llc_v_sns_result,ext_ntc_result,v_sense_result,i_sense_result,cp_neg_result,cp_pos_result,ac_sense_result;

extern unsigned char receive_packet;
extern unsigned char TX_data[100];
extern unsigned char RX_data[100]; // RX storage data
extern unsigned char count;

extern unsigned char received_packet ;

extern UARTstatusDef UART_Status ;
extern unsigned char sys_state,packet_state;
extern int32_t timer_DC;
extern volatile uint16_t EARTH_IC_VAL1, EARTH_IC_VAL2, AC_IC_VAL1, AC_IC_VAL2;
extern volatile uint16_t earth_diff, ac_diff;
extern volatile uint8_t is_first_captured1, is_first_captured2,duty_width;
extern float frequency,width;
extern unsigned short comm_fdcan_cnt;
extern unsigned char disp_state;
extern signed short ntc1_temp_C, ntc2_temp_C, ntc3_temp_C;
extern float temperature,average;
extern unsigned short freq_array[40];
extern unsigned long temp_frequency;
extern unsigned int earth_frequency;

extern unsigned short duty_array[40];
extern unsigned long temp_duty;
extern unsigned int ac_duty;
extern unsigned char bypass_temp_check;
extern unsigned char earth_index;
extern unsigned char ac_index;
extern unsigned short i_ab_count,i_sc_count;
extern unsigned char pfc_count;
extern unsigned char batt_index;
extern unsigned char batt_count;
extern unsigned char ds103_receive;

//Charger Algo variables start

/* CHARGER VARIABLE DECLARATION*/

extern unsigned short I_sense, B_Sense;
extern unsigned short T_sense;
extern double I_Out, Y_Out;
extern unsigned char charging_mode;
extern double error_current, error_voltage;
extern unsigned short KP, KI;
extern unsigned short v_i_Loop;

/* Variables for dummy Code*/
extern float I_DUMMY;
extern float B_DUMMY;
extern unsigned short VOLT_ARR[100];
extern unsigned short I_ARR[100];
extern unsigned short VOLT_SUM;
extern unsigned short CURRENT_SUM;
extern double B_Sense_Cal;
extern double I_Sense_Cal;
extern double delta_Curr;
extern charStatus state_check;
extern unsigned char delta;
extern unsigned int loop;
extern long loop2;
extern uint32_t startTime;
extern uint32_t currentTime;
extern uint32_t mode_sTime; // Mode Start Tick Count.
extern uint32_t mode_eTime; // Mode End Tick Count.
extern uint32_t value_avg;
extern uint32_t deltaTickle;
extern uint32_t deltaSoftStart;
extern uint32_t deltaCC;
extern uint32_t deltaCV;
extern uint32_t deltaTOTALTIME;
extern uint32_t chargerTime;
extern uint32_t chargerEndTime;

extern uint16_t mx_current;
extern uint16_t mx_voltage;
extern uint16_t trickle_charge;
extern uint16_t cuttoff_voltage;
extern uint16_t min_current;
extern unsigned short v_arr[10],i_arr[10];
extern float target_voltage_count, target_current_count;
extern float ERR_VOLTAGE_COUNT,ERR_CURRENT_COUNT;
extern float voltage_calibrate,current_calibrate;
//Charger Algo variables end

#endif

#endif /* INC_VARIABLES_H_ */
