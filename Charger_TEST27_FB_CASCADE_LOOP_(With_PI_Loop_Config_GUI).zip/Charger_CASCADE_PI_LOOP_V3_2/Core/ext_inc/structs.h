/*
 * structs.h
 *
 *  Created on: 05-Dec-2022
 *      Author: abhishekk
 */

#ifndef INC_STRUCTS_H_
#define INC_STRUCTS_H_

typedef struct{
	unsigned char cnt;
	unsigned char mode;
	unsigned char total;
}LEDs;

typedef struct{
	unsigned int adc_arr[11];
	unsigned int avg;
	unsigned int sum;
	unsigned short value1;
	unsigned short value2;
	unsigned short value3;
}ADC_NTC;

typedef struct{
	unsigned char batt_voltage;
	unsigned char batt_percent;//
	unsigned char batt_temp;//
	unsigned char batt_dis_current;//
	unsigned char current_level;
	union{
		struct{
			unsigned char over_voltage 				:	1;
			unsigned char charge_overcurrent		:	1;
			unsigned char discharge_overcurrent		:	1;
			unsigned char short_circuit 			:	1;
			unsigned char charge_discharge_temp 	:	1;
			unsigned char charge_low_temp 			:	1;
			unsigned char under_voltage 			:	1;
			unsigned char low_temp_discharge 		:	1;
		}bits;
		unsigned char byte;
	}error_code;
	unsigned char batt_status;
	union{
		struct{
			unsigned char pri_mosfet				:	2;
			unsigned char transformer 				:	2;
			unsigned char sec_diode 				:	2;
			unsigned char bms		 				:	2;
		}bits;
		unsigned char byte;
	}ntc;
}CHARGER;

typedef union{
	struct{
		unsigned int tx_en				:	1;
		unsigned int rx_en				:	1;
		unsigned int msec_10			:	1;
		unsigned int msec_25			:	1;
		unsigned int msec_250			:	1;
		unsigned int f_array_complt		:	1;
		unsigned int d_array_complt		:	1;
		unsigned int charging			:	1;
		unsigned int can_receive		:	2;
		unsigned int charging_algo		:	1;
		unsigned int setProfile			:	1;
		unsigned int global_error		:	1;
		unsigned int range_timer		:	1;
		unsigned int avg_complt			: 	1;
		unsigned int condition_wait 	:	1;
		unsigned int cc_dac_check		:	1;
		unsigned int cv_dac_check   	:   1;
		unsigned int ac_check  			:   1;
		unsigned int earth_check  		:   1;
		unsigned int pre_pfc_not_ok 	:   1;
		unsigned int feedback_pi_loop  	:   1;
		unsigned int pi_loop_en 		:   1;
		unsigned int us_100_flag			:	1;
		unsigned int request_reset		:	1;
	}bits;
	unsigned int data_info;
}FLAGS;

typedef union{
	struct{
		unsigned char batt_cut_off					:	1;
		unsigned char mos_cut_off					:	1;
		unsigned char reseverd						:	6;
	}bits;
	unsigned char byte;
}HW_STATE;

typedef union{
	struct{
		unsigned short sc_current					:	1;
		unsigned short over_current					:	1;
		unsigned short bms_temp						:	1;
		unsigned short pri_mos_temp					:	1;
		unsigned short transform_temp				:	1;
		unsigned short sec_diode_temp				:	1;
		unsigned short earth_detect					:	1;
		unsigned short ac_over_volt					:	1;
		unsigned short ac_under_volt				:	1;
		unsigned short batt_not_connect				:	1;
		unsigned short batt_reverse					:	1;
		unsigned short pfc_not_ok					:	1;
		unsigned short output_over_voltage			:	1;
		unsigned short can_com_fault				:	1;
		unsigned short batt_volt_not_in_range		:	1;
		unsigned short reserved						:	1;
	}bits;
	unsigned short data;
}FAULTS;

typedef struct{
	union{
		struct{
			unsigned int source_add			:	8;
			unsigned int destination_add	:	8;
			unsigned int message_id			:	9;
			unsigned int reserved_R			:	1;
			unsigned int priority			:	3;
			unsigned int na					:	3;
		}bits;
		unsigned int full_id;
	}identifier;
	unsigned char data_byte[8];
	unsigned char DLC;
}CAN_FORMAT;

typedef struct{
	struct{
		unsigned char type;
		unsigned char ac_input;
		unsigned char temperature;
		unsigned char rms_voltage;
		union{
			struct{
				unsigned char error_state	:	4;
				unsigned char fan			:	1;
				unsigned char output		:	1;
				unsigned char derating		:	1;
				unsigned char reserved		:	1;
			}bits;
			unsigned char byte;
		}status;
	}charger_info;

	struct{
		union{
			struct{
				unsigned char LSB;
				unsigned char MSB;
			}bytes;
			unsigned short word;
		}out_current;
		union{
			struct{
				unsigned char LSB;
				unsigned char MSB;
			}bytes;
			unsigned short word;
		}out_voltage;
	}charger_profile;

	struct{
		union{
			struct{
				unsigned char minor;
				unsigned char major;
			}bytes;
			unsigned short word;
		}number;
		unsigned char iteration_version;
		unsigned char charger_type;
		union{
			struct{
				union{
					struct{
						unsigned char LSB;
						unsigned char MSB;
					}bytes;
					unsigned short value;
				}year;
				unsigned char month;
				unsigned char date;
			}fields;
			unsigned int full_value;
		}sw_release_date;
	}fw_version;
}CAN_TX_PACKET;

typedef struct{
	struct{
		union{
			struct{
				unsigned char LSB;
				unsigned char MSB;
			}bytes;
			unsigned short word;
		}measured_current;
		union{
			struct{
				unsigned char LSB;
				unsigned char MSB;
			}bytes;
			unsigned short word;
		}terminal_voltage;
		unsigned char error_state;
		unsigned char temperature;
	}bms_status;
	struct{
		union{
			struct{
				unsigned char LSB;
				unsigned char MSB;
			}bytes;
			unsigned short word;
		}max_current;
		union{
			struct{
				unsigned char LSB;
				unsigned char MSB;
			}bytes;
			unsigned short word;
		}max_voltage;
		union{
			struct{
				unsigned char LSB;
				unsigned char MSB;
			}bytes;
			unsigned short word;
		}cut_off_current;
		union{
			struct{
				unsigned char LSB;
				unsigned char MSB;
			}bytes;
			unsigned short word;
		}pre_charge_current;
	}bms_profile;
}CAN_RX_PACKET;

typedef enum
{
	NO_OPERATION          =1U,
    FULL_CHARGED          =2U,
    STOP_CHARGING         =3U,
    CONSTANT_CURRENT_MODE =4U,
    CONSTANT_VOLTAGE_MODE =5U,
    TRICKEL_MODE          =6U,
    DEFAULT_MODE          =7U,
	SOFT_START			  =8U,

}charStatus;

typedef enum
{
   HW_OK  =01U,
   HW_NOK =02U,
}HW_Status;


typedef enum
{
    START         =01U,
    STOP          =02U,
    CONDITION_OK  =03U,
    CONDITION_NOK =04U,
    ERR_CONDITION =05U,
}condition_Status;

typedef enum
{
	RANGE_OK =1U,
	RANGE_NOK = 2U,
	OUT_OF_BOUND =3U,
}fb_status;

typedef enum
{
	PROFILE_SET=1U,
	PROFILE_NOT_SET = 2U,
}can_status;

typedef union{
	struct{
		unsigned char byte0;
		unsigned char byte1;
		unsigned char byte2;
		unsigned char byte3;
	}bytes;
	unsigned int dataword;
}_Words;

#endif /* INC_STRUCTS_H_ */
