/*
 * BoilerPlate.h
 *
 *  Created on: Nov 1, 2022
 *      Author: rishabhs
 */

#ifndef INC_BOILERPLATE_H_
#define INC_BOILERPLATE_H_
#include "hardware_input.h"
#include "structs.h"
/* Peripheral Declaration */

/*  Application          - CHARGER 750 Watt
 *  Microcintroller Unit - STM32G0B1
 */

#define DEVICE_TYPE					2

#if		(DEVICE_TYPE		==		2)
#define DEVICE_WATTAGE				750
#elif	(DEVICE_TYPE		==		3)
#define DEVICE_WATTAGE				1350
#else
#define DEVICE_WATTAGE				650
#endif
/*name: fw_array
 * fw_array[0] : major version number \x00 to \xFF
 * fw_array[1] : minor version number \x00 to \xFF
 * fw_array[2] : iteration version number \x00 to \xFF
 * fw_array[3] : Charger Type: 1=>650W, 2=>750W, 3=>1350W
 * fw_array[4] : software release date: \x01 to \x31
 * fw_array[5] : software release month: \x01 to \x12
 * fw_array[4] : SW release year (First two numbers): \x00 to \x99
 * fw_array[4] : SW release year (Last two numbers): \x00 to \x99
 * */
#define fw_array					"\x01\x01\x01\x02\x08\0x12\x20\x22"

#define CP_DUTY						630//63%
#define I2C_DEVICE_ID				0xA0

#define MX_RESOLUTION01				1000.00//0.001 V/bit resolution
#define MX_RESOLUTION15				1000.00//15625.0//0.015625 V/bit resolution
#define MX_RESOLUTION31				1000.00//31250.00//0.03125 A/bit resolution

#define LED1D_H						GPIOD->ODR |=  (1 << 2)
#define LED1D_L						GPIOD->ODR &= ~(1 << 2)
#define LED2D_H						GPIOD->ODR |=  (1 << 1)
#define LED2D_L						GPIOD->ODR &= ~(1 << 1)
#define LED_SOC_H					GPIOA->ODR |=  (1 << 10)
#define LED_SOC_L					GPIOA->ODR &= ~(1 << 10)

#define YELLOW_H					GPIOA->ODR |=  (1 << 8)
#define YELLOW_L					GPIOA->ODR &= ~(1 << 8)
#define RED_H						GPIOA->ODR |=  (1 << 9)
#define RED_L						GPIOA->ODR &= ~(1 << 9)
#define MAINS_H						GPIOB->ODR |=  (1 << 15)
#define MAINS_L						GPIOB->ODR &= ~(1 << 15)
#define FAN_OUT_ON					GPIOB->ODR |=  (1 << 13)
#define FAN_OUT_OFF					GPIOB->ODR &= ~(1 << 13)
#define PFC_CTRL_DISABLE			GPIOB->ODR |=  (1 << 14)
#define PFC_CTRL_ENABLE				GPIOB->ODR &= ~(1 << 14)
#define IN_RLY_ON					GPIOB->ODR |=  (1 << 11)
#define IN_RLY_OFF					GPIOB->ODR &= ~(1 << 11)
#define OUT_RLY_ON					GPIOB->ODR |=  (1 << 12)
#define OUT_RLY_OFF					GPIOB->ODR &= ~(1 << 12)
#define CP_PWM_1_H					GPIOD->ODR |=  (1 << 3)
#define CP_PWM_1_L					GPIOD->ODR &= ~(1 << 3)
#define LLC_CTRL_ENABLE				GPIOB->ODR |=  (1 << 6)
#define LLC_CTRL_DISABLE			GPIOB->ODR &= ~(1 << 6)

#define PFC_OK_LV_IN				(GPIOB->ODR & (1 << 5))
#define AC_SEN_LV_IN				(GPIOF->ODR & (1 << 1))
#define EARTH_DETECT_IN				(GPIOB->ODR & (1 << 8))
#define PP_MCU_IN					(GPIOB->ODR & (1 << 2))
#define SWITCH_IN					(GPIOC->ODR & (1 << 13))

#define OFF							0
#define ON							1
#define BLINK						2
#define BLINK25						3

#define CHARGING					0x0A
#define CUT_OFF						0x0B
#define CHARGED						0x0C
#define COM_FLT						0x0D
#define OVR_VOLT					0x0E
#define UND_VOLT					0x0F
#define AB_EARTH					0x10
#define PFC_FAIL					0x11
#define MOS_OT						0x12
#define TRFMR_OT					0x13
#define DIODE_OT					0x14
#define BMS_OT						0x15
#define BATT_NOT_CN					0x16
#define BATT_REV					0x17
#define CHARGE_OV					0x18
#define CHARGE_OC					0x19
#define CHARGE_SC					0x1A
#define BATT_NO_RANGE				0x1B

#define MOS_TEMP_115_DEGREE			(signed short)115
#define MOS_TEMP_105_DEGREE			(signed short)105
#define MOS_TEMP_95_DEGREE			(signed short)95

#define HIGH_TEMP_NTC2				(signed short)MOS_TEMP_115_DEGREE
#define LOW_TEMP_NTC2				(signed short)(MOS_TEMP_115_DEGREE - 2)

#define HIGH_TEMP_NTC1				(signed short)100
#define LOW_TEMP_NTC1				(signed short)98

#define HIGH_TEMP_NTC3				(signed short)100
#define LOW_TEMP_NTC3				(signed short)98

#define STATE_NOT_CHARGING			0
#define STATE_CHARGING				1
#define STATE_BROWN					2

#define beta_103AT_2				3435
#define beta_103AT_4				3435
#define beta_103JT_025				3435

#define nominal_resistance 			10000  			//Nominal resistance at 25°C
#define nominal_temeprature 		25   			// temperature for nominal resistance (almost always 25° C)
#define beta 						beta_103AT_2  	// The beta coefficient or the B value of the thermistor
													//(usually 3000-4000) check the datasheet for the accurate value.
#define Rref 						10000   		//Value of  resistor used for the voltage divider

#define UNDER_VOLTAGE			    165.0
#define OVER_VOLTAGE				270.0
#define VOLTAGE_RATIO				41.0

#define UNDER_VOLTAGE_LIMIT			(unsigned char)((((UNDER_VOLTAGE * 1.414) / VOLTAGE_RATIO) - 0.08) * 10.75)
#define OVER_VOLTAGE_LIMIT			(unsigned char)((((OVER_VOLTAGE * 1.414) / VOLTAGE_RATIO) - 0.08) * 10.75)

#define U_REC_VOLTAGE_LIMIT			(unsigned char)(((((UNDER_VOLTAGE+20.0) * 1.414) / VOLTAGE_RATIO) - 0.08) * 10.75)
#define O_REC_VOLTAGE_LIMIT			(unsigned char)(((((OVER_VOLTAGE-20.0) * 1.414) / VOLTAGE_RATIO) - 0.08) * 10.75)

#define PRI_MOS_TEMP_HIGH			(unsigned short)115
#define PRI_MOS_TEMP_MID			(unsigned short)105
#define PRI_MOS_TEMP_NORM			(unsigned short)95

#define TRNSFMR_TEMP_HIGH			(unsigned short)55
#define TRNSFMR_TEMP_MID			(unsigned short)48
#define TRNSFMR_TEMP_NORM			(unsigned short)40

#define S_DIODE_TEMP_HIGH			(unsigned short)55
#define S_DIODE_TEMP_MID			(unsigned short)48
#define S_DIODE_TEMP_NORM			(unsigned short)40

#define BMS_TEMP_HIGH				(unsigned short)55
#define BMS_TEMP_MID				(unsigned short)48
#define BMS_TEMP_NORM				(unsigned short)40

#define NORM						0
#define LVL1						1
#define LVL2						2
#define HIGH						3

#define VAL_TO_mVOLT(v)				(unsigned int)((3300 / 4095) * v)
#define HIGH_LIMIT_V				3.0// for 3V
#define HIGH_LIMIT_VAL				(unsigned short)((HIGH_LIMIT_V / 3.3)*4095)//High limit count

//considering 3.0V at Bat_I_Sense = 12.5Amp
#define NOMINAL_CURRENT				12.5	//for 12.5Amp
#define ABNORMAL_CURRENT			13.0	//for 13.0Amp
#define SC_CURRENT					13.5	//for 13.5Amp
#define ABNORMAL_CURRENT_VAL		13.0//Amp(unsigned short)(HIGH_LIMIT_VAL * (ABNORMAL_CURRENT / NOMINAL_CURRENT))
#define SC_CURRENT_VAL				15.0//Amp (unsigned short)(HIGH_LIMIT_VAL * (SC_CURRENT / NOMINAL_CURRENT))
//considering 3.0V at Bat_V_Sense = 60V
#define CHARGER_MAX_VOLTAGE			60//3.0V
#define ABNORMAL_VOLTAGE			61// in volts
#define ABNORMAL_VOLTAGE_VAL		61.0//(unsigned short)(HIGH_LIMIT_VAL * (ABNORMAL_VOLTAGE / CHARGER_MAX_VOLTAGE))
#define BATT_NOT_CONN_VAL			0.1//V (0.1/3.3)*4095//0.1V for battery not connect range

typedef enum
{
  TX_ACTIVE = 00U,
  TX_ERR= 01U,
  TX_TIMEOUT = 02U,
  TX_BUSY = 04U,
  TX_NOACTIVE = 05U,
}UARTstatusDef;

//Charger Algo Macros start
/*Buffer Count*/
#define TOTAL_COUNT			10
/*Buffer Count for CV*/
#define WAIT_TIME			100000000U
/*ABSTRACT VARIABLES*/
#define RANDOM              50000
/*Pre Set Maximum Charging Voltage*/
#define MAX_VOLTAGE         48
/*Pre Set Minimum Charging Current*/
#define MAX_CURRENT         15
/*Nominal Current for signal level*/
#define SIGNAL_NOMINALCURRENT 2.64
/*Pre Set Small Current */
#define MIN_CURRENT         3
/*Pre Set Voltage CuttOff for Lithium Ion Battery*/
/* Cutt off voltage is around 70.7% of the Maximum value*/
#define CUTOFF_VOLTAGE      33

#define CHAR_CURR_0_0       0
#define CHAR_CURR_0_1       (4095*(0.1*NOMINAL_CURRENT))/MAX_CURRENT
#define CHAR_CURR_0_2		(4095*(0.2*NOMINAL_CURRENT))/MAX_CURRENT
#define CHAR_CURR_0_4		(4095*(0.4*NOMINAL_CURRENT))/MAX_CURRENT
#define CHAR_CURR_0_5       (4095*(0.5*NOMINAL_CURRENT))/MAX_CURRENT
#define CHAR_CURR_1_0       (4095*(1*NOMINAL_CURRENT))/MAX_CURRENT
#define CHAR_CURR_1_5       (4095*(1.5*NOMINAL_CURRENT))/MAX_CURRENT
#define CHAR_CURR_2_0       (4095*(2.0*NOMINAL_CURRENT))/MAX_CURRENT
#define CHAR_CURR_2_5       (4095*(2.5*NOMINAL_CURRENT))/MAX_CURRENT
#define CHAR_CURR_3_0       (4095*(3.0*NOMINAL_CURRENT))/MAX_CURRENT

#define SOFT_CURR_0_1		(4095*1)/MAX_CURRENT
#define SOFT_CURR_1_0       (4095*1)/MAX_CURRENT
#define SOFT_CURR_2_0       (4095*2)/MAX_CURRENT
#define SOFT_CURR_3_0       (4095*3)/MAX_CURRENT

//100mA
#define C_100MA          	(4095*0.1)/MAX_CURRENT
//200mA
#define C_200MA				(4095*0.2)/MAX_CURRENT
//300mA
#define C_300MA				(4095*0.3)/MAX_CURRENT
//400mA
#define C_400MA				(4095*0.4)/MAX_CURRENT
//500mA
#define C_500MA				(4095*0.5)/MAX_CURRENT
//600mA
#define C_600MA				(4095*0.6)/MAX_CURRENT
//700mA
#define C_700MA				(4095*0.7)/MAX_CURRENT
//800mA
#define C_800MA				(4095*0.8)/MAX_CURRENT
//1A
#define C_1000MA			(4095*1)/MAX_CURRENT
//1.5A
#define C_1500MA			(4095*1.5)/MAX_CURRENT
//2A
#define C_2000MA			(4095*2)/MAX_CURRENT

#define MAX_COUNTS			(4095)
//C-Rate Defined

// C-RATE --> 0.1C
#define C_RATE_0_1          (0.1*4095)
// C-RATE --> 0.25C
#define C_RATE_0_25			(0.25*4095)
// C-RATE -->  0.5C
#define C_RATE_0_5			(0.5*4095)
// C-RATE -->  1C
#define C_RATE_1_0			(1*4095)

typedef enum{
SOFT_MODE = 0,
CC_MODE,
CV_MODE
}cv_cc_type;
//#define CHARGED             3
#define TRICKLE_MODE        4


#define OUT_OF_BOUND_TIMEOUT 50000
//Charger Algo MAcros END


enum{
NOT_DONE = 0,
DONE
};

#define CC_CURRENT_LEVEL	12.0

enum{
	STANDBY = 0,
	TRICKLE_CHARGE,
	CONSTANT_CURRENT,
	CONSTANT_VOLTAGE,
	CHARGE_COMPLETE
};


#endif /* INC_BOILERPLATE_H_ */
