/*
 * charger_function.h
 *
 *  Created on: 15-Nov-2022
 *      Author: rishabhs
 */

#ifndef INC_CHARGER_FUNCTION_H_
#define INC_CHARGER_FUNCTION_H_


charStatus charging_curve(void);
charStatus trickle_mode_start(void);
condition_Status CC_condition(void);
condition_Status CV_condition(void);
void soft_start(void);
void cc_mode_state(void);
void cv_mode_state(void);
void stop_charging(void);
void soft_start_dac_out(void);
charStatus cv_dac_out(void);
charStatus cc_dac_out(void);
HW_Status check_HWfault(void);

void ADC_Read(void);
void ADC_aveg_Val(void);

int FB_DAC_CURR(float CURR_IN); // DAC out with respect to Battery Current.
int FB_DAC_VOLT(float VOLT_IN); // DAC out with respect to Battery Voltage.

fb_status delta_check(double,double, double, double);
uint32_t millis(void);

/* CHARGING Profile Setting API's */
can_status setProfiling(void);

void start_tim(void);


#endif /* INC_CHARGER_FUNCTION_H_ */
