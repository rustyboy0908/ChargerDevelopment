/*
 * functions.h
 *
 *  Created on: Nov 4, 2022
 *      Author: abhishekk
 */

#ifndef INC_FUNCTIONS_H_
#define INC_FUNCTIONS_H_

//peripherals.c
void user_setup(void);
void user_loop(void);
void ADC_Read(void);
void ADC_Sample(void);
void ADC_calc(void);
void key_operation(void);
void FB_CV_OUT(unsigned short value);
void FB_CC_OUT(unsigned short value);
void cp_pwm_out(unsigned int period,unsigned char duty);
void average_data(void);

//uart.c
void process_uart(unsigned char data);

//process.c
void user_loop(void);
void key_sense(void);
void key_operation(void);
void update_in_10ms(void);
void update_in_25ms(void);
void update_in_250ms(void);
void adc_reading_states(void);
int func_ntc1(void);
int func_ntc2(void);
int func_ntc3(void);
void ntc1_decision(void);
void llc_v_decision(void);
//void ntc2_decision(void);
void ntc3_decision(void);
void temperature_control(void);
void check_for_decrease_current(void);
void check_for_current_recovery(void);
void state_machine(void);
signed short adc_to_temp(unsigned short adc_val);
void update_in_10us(void);

//led_core.c
void leds_run(void);
void run_red_led(void);
void run_yellow_led(void);
void run_mains_led(void);
void set_leds(LEDs *ledx, unsigned char mode);
void charging_ind(void);
void cut_off_ind(void);
void charged_ind(void);
void comm_flt_ind(void);
void stage_HMI(unsigned char value);
void over_voltage_ind(void);
void under_voltage_ind(void);
void abnormal_earth_ind(void);
void pfc_failure_ind(void);
void mosfet_over_temp(void);
void transformer_over_temp(void);
void diode_over_temp(void);
void bms_over_temp(void);
void cut_off_ind(void);
void short_circuit_ind(void );
void battery_reverse_ind(void);
void voltage_not_in_range_ind(void);
void battery_not_connect_ind(void);
void charger_over_voltage_ind(void);
void charger_over_current_ind(void);

//fdcan.c
void CAN_initial_setup(void);
void set_receive_rules(void);
void fdcan_write_bytes(unsigned int CAN_ID, uint8_t *dat, unsigned char DLC);
void send_can_packets(void);
void gen_send_packet(void);
void supp_send_packet(void);
void process_fdcan_rx0(FDCAN_RxHeaderTypeDef *pRxHeader,uint8_t *dat);
void process_fdcan_rx1(FDCAN_RxHeaderTypeDef *pRxHeader,uint8_t *dat);
void decode_bms_status(unsigned char *comm_array);
void decode_bms_profile(unsigned char *comm_array);
void decode_pi_loop(unsigned char *comm_array);
void decode_ovp_uvp(unsigned char *comm_array);
void encode_pi_loop(void);
void charger_info_update(void);
void charger_profile_update(void);
void charger_fw_version_update(void);
void config_update_feedback(void);
void fdcan_handler(void);

//abnormal.c
void earth_detection(void);
void ac_sensing(void);
void error_handler(void);
void restart_system(void);
void check_for_hard_fault(void);
void check_output_current(void);
void check_pfc(void);
void check_for_battery(void);
void check_for_battery_config(void);
void check_for_communication(void);
void start_LLC(void);

//pi_loop.c
void delay_us(unsigned int val);
void read_battery(void);
void read_llc_voltage(void);
void read_batt_current(void);
void read_inst_battery(void);
void read_inst_batt_current(void);
void charging_process(void);
void change_to_standby(void);
void change_to_trickle(void);
void change_to_cc(void);
void change_to_cv(void);
void change_to_charged(void);
void charging_control(void);

void tim16_handler(void);

//extras.c
void update_target_voltage(float out_voltage);
void update_target_current(float out_current);
void pi_loop_new3(void);
#endif /* INC_FUNCTIONS_H_ */
