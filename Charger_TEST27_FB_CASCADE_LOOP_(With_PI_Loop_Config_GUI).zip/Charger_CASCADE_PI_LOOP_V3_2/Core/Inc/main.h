/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.h
  * @brief          : Header for main.c file.
  *                   This file contains the common defines of the application.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2023 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32g0xx_hal.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "math.h"
#include "string.h"
#include "BoilerPlate.h"
#include "variables.h"
#include "hardware_input.h"
#include "charger_function.h"
#include "i2c.h"
#include "stm32g0xx_it.h"
#include "functions.h"
/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
/* USER CODE BEGIN ET */

/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
/* USER CODE BEGIN EC */

/* USER CODE END EC */

/* Exported macro ------------------------------------------------------------*/
/* USER CODE BEGIN EM */

/* USER CODE END EM */

void HAL_TIM_MspPostInit(TIM_HandleTypeDef *htim);

/* Exported functions prototypes ---------------------------------------------*/
void Error_Handler(void);

/* USER CODE BEGIN EFP */

/* USER CODE END EFP */

/* Private defines -----------------------------------------------------------*/
#define SWITCH_Pin GPIO_PIN_13
#define SWITCH_GPIO_Port GPIOC
#define LLC_DRV_H_Pin GPIO_PIN_1
#define LLC_DRV_H_GPIO_Port GPIOF
#define AC_SENSE_LV_Pin GPIO_PIN_0
#define AC_SENSE_LV_GPIO_Port GPIOA
#define LLC_DRV_L_Pin GPIO_PIN_1
#define LLC_DRV_L_GPIO_Port GPIOA
#define BAT_I_SENSE_MCU_Pin GPIO_PIN_2
#define BAT_I_SENSE_MCU_GPIO_Port GPIOA
#define BAT_V_SNS_Pin GPIO_PIN_3
#define BAT_V_SNS_GPIO_Port GPIOA
#define FB_CV_MCU_Pin GPIO_PIN_4
#define FB_CV_MCU_GPIO_Port GPIOA
#define FB_CC_MCU_Pin GPIO_PIN_5
#define FB_CC_MCU_GPIO_Port GPIOA
#define EXT_NTC_1_Pin GPIO_PIN_6
#define EXT_NTC_1_GPIO_Port GPIOA
#define CP_NEG_SNS_Pin GPIO_PIN_7
#define CP_NEG_SNS_GPIO_Port GPIOA
#define CP_POS_SNS_Pin GPIO_PIN_0
#define CP_POS_SNS_GPIO_Port GPIOB
#define LLC_V_SNS_Pin GPIO_PIN_1
#define LLC_V_SNS_GPIO_Port GPIOB
#define PP_MCU_Pin GPIO_PIN_2
#define PP_MCU_GPIO_Port GPIOB
#define NTC1_Pin GPIO_PIN_10
#define NTC1_GPIO_Port GPIOB
#define IN_RLY_Pin GPIO_PIN_11
#define IN_RLY_GPIO_Port GPIOB
#define OUT_RLY_Pin GPIO_PIN_12
#define OUT_RLY_GPIO_Port GPIOB
#define FAN_OUT_Pin GPIO_PIN_13
#define FAN_OUT_GPIO_Port GPIOB
#define PFC_EN_LV_Pin GPIO_PIN_14
#define PFC_EN_LV_GPIO_Port GPIOB
#define LED_MAINS_Pin GPIO_PIN_15
#define LED_MAINS_GPIO_Port GPIOB
#define LED_YELLOW_Pin GPIO_PIN_8
#define LED_YELLOW_GPIO_Port GPIOA
#define LED_RED_Pin GPIO_PIN_9
#define LED_RED_GPIO_Port GPIOA
#define UART_TX_Pin GPIO_PIN_6
#define UART_TX_GPIO_Port GPIOC
#define UART_RX_Pin GPIO_PIN_7
#define UART_RX_GPIO_Port GPIOC
#define LED_SOC_Pin GPIO_PIN_10
#define LED_SOC_GPIO_Port GPIOA
#define CAN_RX_Pin GPIO_PIN_11
#define CAN_RX_GPIO_Port GPIOA
#define CAN_TX_Pin GPIO_PIN_12
#define CAN_TX_GPIO_Port GPIOA
#define CP_PWM_1_Pin GPIO_PIN_15
#define CP_PWM_1_GPIO_Port GPIOA
#define LED2D_Pin GPIO_PIN_1
#define LED2D_GPIO_Port GPIOD
#define LED1D_Pin GPIO_PIN_2
#define LED1D_GPIO_Port GPIOD
#define SCL_Pin GPIO_PIN_3
#define SCL_GPIO_Port GPIOB
#define SDA_Pin GPIO_PIN_4
#define SDA_GPIO_Port GPIOB
#define PFC_OK_LV_Pin GPIO_PIN_5
#define PFC_OK_LV_GPIO_Port GPIOB
#define LLC_CTRL_LV_Pin GPIO_PIN_6
#define LLC_CTRL_LV_GPIO_Port GPIOB
#define EARTH_DETECT_Pin GPIO_PIN_8
#define EARTH_DETECT_GPIO_Port GPIOB

/* USER CODE BEGIN Private defines */

/* USER CODE END Private defines */

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */
